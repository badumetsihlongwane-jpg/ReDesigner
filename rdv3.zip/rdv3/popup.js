// popup.js — Multi-Provider Controller, Live Model Discovery & CSS Inspector

const PROVIDER_CONFIG = {
  nvidia: {
    name: "NVIDIA NIM API Key",
    placeholder: "nvapi-...",
    modelsUrl: "https://integrate.api.nvidia.com/v1/models",
    defaultModels: [
      { id: "meta/llama-3.2-90b-vision-instruct", label: "Llama 3.2 90B Vision (Multimodal)" },
      { id: "meta/llama-3.2-11b-vision-instruct", label: "Llama 3.2 11B Vision (Fast Multimodal)" },
      { id: "deepseek-ai/deepseek-v4.1-flash", label: "DeepSeek v4.1 Flash" },
      { id: "moonshotai/kimi-k2.6", label: "Moonshot Kimi K2.6" }
    ]
  },
  groq: {
    name: "Groq API Key",
    placeholder: "gsk_...",
    modelsUrl: "https://api.groq.com/openai/v1/models",
    defaultModels: [
      { id: "meta-llama/llama-4-scout-17b-16e-instruct", label: "Llama 4 Scout 17B Vision" },
      { id: "meta-llama/llama-4-maverick-17b-128e-instruct", label: "Llama 4 Maverick 17B Vision" },
      { id: "llama-3.3-70b-versatile", label: "Llama 3.3 70B Versatile" },
      { id: "qwen/qwen3.8-27b", label: "Qwen 3.8 27B Vision" }
    ]
  },
  openrouter: {
    name: "OpenRouter API Key",
    placeholder: "sk-or-v1-...",
    modelsUrl: "https://openrouter.ai/api/v1/models",
    defaultModels: [
      { id: "google/gemini-2.0-flash-001", label: "Gemini 2.0 Flash (Vision)" },
      { id: "qwen/qwen-2.5-vl-72b-instruct:free", label: "Qwen 2.5 VL 72B (Free Vision)" },
      { id: "anthropic/claude-3.5-sonnet", label: "Claude 3.5 Sonnet (Vision)" },
      { id: "openai/gpt-4o-mini", label: "GPT-4o Mini (Vision)" }
    ]
  },
  gemini: {
    name: "Gemini API Key",
    placeholder: "AIzaSy...",
    modelsUrl: "https://generativelanguage.googleapis.com/v1beta/models",
    defaultModels: [
      { id: "gemini-3.5-flash-lite", label: "Gemini 3.5 Flash-Lite (Fastest / Low Traffic)" },
      { id: "gemini-3.1-flash-lite", label: "Gemini 3.1 Flash-Lite" },
      { id: "gemini-3.6-flash", label: "Gemini 3.6 Flash" },
      { id: "gemini-omni-1.1-flash", label: "Gemini Omni 1.1 Flash" },
      { id: "gemini-3.8-flash", label: "Gemini 3.8 Flash (Auto-Fallbacks on High Traffic)" },
      { id: "gemini-3.1-pro-preview", label: "Gemini 3.1 Pro Preview" },
      { id: "gemini-3-flash-preview", label: "Gemini 3 Flash Preview" },
      { id: "gemini-flash-latest", label: "Gemini Flash Latest" },
      { id: "gemini-nano-banana-2.1", label: "Nano Banana 2.1 (gemini-nano-banana-2.1)" },
      { id: "gemini-3.1-flash-image", label: "Nano Banana 2 (gemini-3.1-flash-image)" },
      { id: "gemini-3.1-flash-lite-image", label: "Nano Banana 2 Lite (gemini-3.1-flash-lite-image)" },
      { id: "gemini-3-pro-image", label: "Nano Banana Pro (gemini-3-pro-image)" },
      { id: "gemini-3.8-live", label: "Gemini 3.8 Live" },
      { id: "gemini-3.8-live-extended-thinking", label: "Gemini 3.8 Live Extended Thinking" }
    ]
  }
};

let timerInterval = null;
let secondsElapsed = 0;

function initPopup() {
  const providerSelect = document.getElementById("provider-select");
  const agentModeSelect = document.getElementById("agent-mode-select");
  const modelSelect = document.getElementById("model-select");
  const customModelInput = document.getElementById("custom-model-input");
  const apiKeyLabel = document.getElementById("api-key-label");
  const apiKeyInput = document.getElementById("api-key");
  const btnFetchModels = document.getElementById("btn-fetch-models");
  const promptInput = document.getElementById("user-prompt");
  const btnAutonomous = document.getElementById("btn-autonomous");
  const btnRun = document.getElementById("btn-run");
  const btnCompare = document.getElementById("btn-compare");
  const btnRevert = document.getElementById("btn-revert");
  const btnClearLogs = document.getElementById("btn-clear-logs");
  const btnToggleDesigns = document.getElementById("btn-toggle-designs");
  const designsCountEl = document.getElementById("designs-count");
  const designsDrawer = document.getElementById("designs-drawer");
  const savedDesignsList = document.getElementById("saved-designs-list");
  const drawerTabs = document.querySelectorAll(".drawer-tab");
  const btnPinSite = document.getElementById("btn-pin-site");
  const btnLikeCurrent = document.getElementById("btn-like-current");
  const btnToggleCss = document.getElementById("btn-toggle-css");
  const cssInspector = document.getElementById("css-inspector");
  const cssEditor = document.getElementById("css-editor");
  const cssDirectionLabel = document.getElementById("css-direction-label");
  const btnApplyCss = document.getElementById("btn-apply-css");
  const btnCopyCss = document.getElementById("btn-copy-css");
  const terminalLogs = document.getElementById("terminal-logs");
  const checklistEl = document.getElementById("checklist");
  const timerDisplay = document.getElementById("cockpit-timer");
  const presetButtons = document.querySelectorAll(".preset-pill");
  const defaultChecklistHTML = checklistEl ? checklistEl.innerHTML : "";

  let activeTabHostname = "";
  let currentTabEnforced = false;
  let currentDesignFilter = "all";

  function populateModelList(models, savedModel) {
    modelSelect.innerHTML = "";
    models.forEach((m) => {
      const opt = document.createElement("option");
      opt.value = m.id;
      opt.textContent = m.label || m.id;
      if (savedModel && savedModel === m.id) opt.selected = true;
      modelSelect.appendChild(opt);
    });
  }

  function updateProviderUI(providerKey, savedModel) {
    const config = PROVIDER_CONFIG[providerKey] || PROVIDER_CONFIG.nvidia;
    apiKeyLabel.innerText = config.name;
    apiKeyInput.placeholder = config.placeholder;

    chrome.storage.local.get(
      [`apiKey_${providerKey}`, `fetchedModels_${providerKey}`],
      (res) => {
        apiKeyInput.value = res[`apiKey_${providerKey}`] || "";
        const cachedModels = res[`fetchedModels_${providerKey}`];
        if (Array.isArray(cachedModels) && cachedModels.length > 0) {
          const seen = new Set(config.defaultModels.map((m) => m.id));
          const merged = [
            ...config.defaultModels,
            ...cachedModels.filter((m) => !seen.has(m.id))
          ];
          populateModelList(merged, savedModel);
        } else {
          populateModelList(config.defaultModels, savedModel);
        }
      }
    );
  }

  // Restore saved state & inspect active tab
  chrome.storage.local.get(
    [
      "selectedProvider",
      "selectedAgentMode",
      "selectedModel",
      "customModel",
      "lastPrompt",
      "agentRunState",
      "lastGeneratedCSS",
      "lastDesignDirection"
    ],
    (res) => {
      const provider = res.selectedProvider || "gemini";
      providerSelect.value = provider;
      agentModeSelect.value = res.selectedAgentMode || "react";
      updateProviderUI(provider, res.selectedModel);
      if (res.customModel) customModelInput.value = res.customModel;
      if (res.lastPrompt) promptInput.value = res.lastPrompt;

      if (res.lastGeneratedCSS) {
        cssEditor.value = res.lastGeneratedCSS;
      }
      if (res.lastDesignDirection) {
        cssDirectionLabel.textContent = res.lastDesignDirection;
      }

      if (res.agentRunState) {
        restoreCockpitState(res.agentRunState);
        if (res.agentRunState.isRunning) {
          setRunningState(true);
          const elapsed = res.agentRunState.startedAt
            ? Math.max(0, Math.floor((Date.now() - res.agentRunState.startedAt) / 1000))
            : 0;
          startTimer(elapsed);
        }
      }
    }
  );

  // Sync live state from active tab if available
  chrome.tabs.query({ active: true, currentWindow: true }, ([tab]) => {
    if (!tab?.id) return;
    try {
      activeTabHostname = new URL(tab.url || "").hostname || "";
    } catch {}
    chrome.tabs.sendMessage(tab.id, { action: "GET_CURRENT_STATE" }, (state) => {
      if (!chrome.runtime.lastError && state) {
        if (state.hostname) activeTabHostname = state.hostname;
        if (state.hasRedesign && state.cssRules) {
          cssEditor.value = state.cssRules;
          if (state.designDirection) cssDirectionLabel.textContent = state.designDirection;
          updateCompareButtonUI(state.isPreviewDisabled);
        }
        updatePinButtonUI(Boolean(state.isEnforcedOnSite));
      }
      refreshSavedDesignsGallery();
    });
  });

  providerSelect.addEventListener("change", () => {
    updateProviderUI(providerSelect.value);
    chrome.storage.local.set({ selectedProvider: providerSelect.value });
  });

  agentModeSelect.addEventListener("change", () => {
    chrome.storage.local.set({ selectedAgentMode: agentModeSelect.value });
  });

  // Live Model Discovery across NVIDIA NIM, Groq, OpenRouter, and Gemini
  btnFetchModels.addEventListener("click", async () => {
    const provider = providerSelect.value;
    const config = PROVIDER_CONFIG[provider];
    const key = apiKeyInput.value.trim();

    if (!key && provider !== "openrouter") {
      appendLog(`Error: Paste your ${config.name} first to query models.`, "error");
      apiKeyInput.focus();
      return;
    }

    appendLog(`Querying live models from ${provider.toUpperCase()}...`, "action");
    btnFetchModels.innerText = "Querying...";

    try {
      let url = config.modelsUrl;
      const headers = {};
      if (provider === "gemini") {
        headers["x-goog-api-key"] = key;
      } else if (key) {
        headers.Authorization = `Bearer ${key}`;
      }

      const res = await fetch(url, { headers });
      if (!res.ok) throw new Error(`HTTP ${res.status}: ${res.statusText}`);

      const json = await res.json();
      let rawList = [];

      if (provider === "gemini") {
        rawList = (json.models || [])
          .filter((m) => (m.supportedGenerationMethods || []).includes("generateContent"))
          .map((m) => {
            const id = m.name.replace(/^models\//, "");
            return { id, label: m.displayName ? `${id} (${m.displayName})` : id };
          });
      } else {
        rawList = (json.data || []).map((m) => ({
          id: m.id,
          label: m.id
        }));
      }

      if (rawList.length === 0) throw new Error("No active models returned for this key.");

      // Sort vision/multimodal models to the top for convenience
      rawList.sort((a, b) => {
        const aVis = /vision|vl|flash|4o|claude-3|scout|maverick|kimi/i.test(a.id) ? 0 : 1;
        const bVis = /vision|vl|flash|4o|claude-3|scout|maverick|kimi/i.test(b.id) ? 0 : 1;
        return aVis - bVis || a.id.localeCompare(b.id);
      });

      populateModelList(rawList);
      chrome.storage.local.set({
        [`apiKey_${provider}`]: key,
        [`fetchedModels_${provider}`]: rawList
      });

      appendLog(`✓ Loaded ${rawList.length} models from ${provider.toUpperCase()}!`, "success");
    } catch (err) {
      appendLog(`Failed to list models: ${err.message}`, "error");
    } finally {
      btnFetchModels.innerText = "↻ Fetch Models";
    }
  });

  presetButtons.forEach((btn) => {
    btn.addEventListener("click", (e) => {
      e.preventDefault();
      promptInput.value = btn.getAttribute("data-prompt");
      presetButtons.forEach((p) => p.classList.remove("active"));
      btn.classList.add("active");
    });
  });

  btnClearLogs.addEventListener("click", () => {
    terminalLogs.innerHTML = `<div class="log-entry system">[Cleared] Standing by.</div>`;
    chrome.storage.local.remove(["agentRunState"]);
    resetChecklist();
  });

  btnToggleDesigns?.addEventListener("click", () => {
    designsDrawer?.classList.toggle("hidden");
    refreshSavedDesignsGallery();
  });

  drawerTabs.forEach((tabBtn) => {
    tabBtn.addEventListener("click", () => {
      drawerTabs.forEach((b) => b.classList.remove("active"));
      tabBtn.classList.add("active");
      currentDesignFilter = tabBtn.dataset.tab || "all";
      refreshSavedDesignsGallery();
    });
  });

  btnPinSite?.addEventListener("click", async () => {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.id) return;
    const nextEnforced = !currentTabEnforced;
    chrome.tabs.sendMessage(
      tab.id,
      { action: "SET_ENFORCED_STATE", enforced: nextEnforced },
      (res) => {
        if (chrome.runtime.lastError || !res) {
          appendLog("Apply a design first before pinning to site.", "cooldown");
          return;
        }
        updatePinButtonUI(res.isEnforcedOnSite);
        appendLog(
          res.isEnforcedOnSite
            ? `📌 Design enforced on ${activeTabHostname || "this site"} (loads pre-paint on every visit).`
            : `Unpinned auto-enforce for ${activeTabHostname || "this site"}.`,
          "system"
        );
      }
    );
  });

  btnLikeCurrent?.addEventListener("click", () => {
    const css = cssEditor.value.trim();
    if (!css) {
      appendLog("No CSS to save/like yet.", "cooldown");
      return;
    }
    chrome.storage.local.get(["savedDesignsLibrary"], (res) => {
      const list = Array.isArray(res?.savedDesignsLibrary) ? res.savedDesignsLibrary : [];
      let existing = list.find((d) => d.cssRules === css);
      if (existing) {
        existing.liked = !existing.liked;
      } else {
        existing = {
          id: `design_${Date.now()}`,
          hostname: activeTabHostname || "custom",
          designDirection: cssDirectionLabel.textContent || "Liked Custom Design",
          cssRules: css,
          swatches: ["#0b0f17", "#141a26", "#4ade80"],
          liked: true,
          createdAt: Date.now()
        };
        list.unshift(existing);
      }
      chrome.storage.local.set({ savedDesignsLibrary: list.slice(0, 35) }, () => {
        btnLikeCurrent.textContent = existing.liked ? "♥ Liked" : "♡ Like";
        refreshSavedDesignsGallery();
      });
    });
  });

  btnToggleCss.addEventListener("click", () => {
    cssInspector.classList.toggle("hidden");
  });

  btnApplyCss.addEventListener("click", async () => {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.id) return;
    const editedCSS = cssEditor.value;
    chrome.tabs.sendMessage(
      tab.id,
      {
        action: "APPLY_REDESIGN",
        patch: {
          cssRules: editedCSS,
          designDirection: "Custom Live CSS Edits",
          domMutations: []
        }
      },
      () => {
        if (chrome.runtime.lastError) {
          appendLog("Could not apply CSS: refresh tab first.", "error");
        } else {
          chrome.storage.local.set({ lastGeneratedCSS: editedCSS });
          updateCompareButtonUI(false);
          appendLog("✓ Live CSS edits applied to active tab.", "success");
        }
      }
    );
  });

  btnCopyCss.addEventListener("click", async () => {
    const css = cssEditor.value.trim();
    if (!css) {
      appendLog("No generated CSS to copy yet.", "cooldown");
      return;
    }
    try {
      await navigator.clipboard.writeText(css);
      btnCopyCss.textContent = "Copied!";
      setTimeout(() => {
        btnCopyCss.textContent = "Copy CSS";
      }, 1400);
    } catch {
      appendLog("Clipboard copy failed.", "error");
    }
  });

  chrome.runtime.onMessage.addListener((msg) => {
    if (msg.action === "AGENT_TODOS_UPDATE" && Array.isArray(msg.todos)) {
      renderDynamicTodos(msg.todos);
    } else if (msg.action === "AGENT_STEP_UPDATE") {
      updateStepUI(msg.step, msg.status, msg.desc);
    } else if (msg.action === "AGENT_LOG") {
      appendLog(msg.text, msg.logType || "action");
    }
  });

  async function triggerPipeline(customPrompt) {
    const provider = providerSelect.value;
    const agentMode = agentModeSelect.value;
    const model = customModelInput.value.trim() || modelSelect.value;
    const apiKey = apiKeyInput.value.trim();

    if (!apiKey) {
      apiKeyInput.classList.add("input-error");
      apiKeyInput.focus();
      appendLog("Error: Missing API key for " + PROVIDER_CONFIG[provider].name, "error");
      return;
    }
    apiKeyInput.classList.remove("input-error");

    chrome.storage.local.set({
      [`apiKey_${provider}`]: apiKey,
      selectedProvider: provider,
      selectedAgentMode: agentMode,
      selectedModel: modelSelect.value,
      customModel: customModelInput.value.trim(),
      lastPrompt: customPrompt
    });

    resetChecklist();
    startTimer(0);
    setRunningState(true);
    updateCompareButtonUI(false);
    appendLog(
      `Starting ${agentMode === "react" ? "ReAct Tool Loop" : "2-Pass Pipeline"} on ${provider.toUpperCase()} (${model})...`,
      "system"
    );

    chrome.runtime.sendMessage(
      {
        action: "START_AGENT_PIPELINE",
        userPrompt: customPrompt,
        apiKey,
        model,
        provider,
        agentMode
      },
      (response) => {
        stopTimer();
        setRunningState(false);
        if (chrome.runtime.lastError) {
          appendLog(`Connection Error: ${chrome.runtime.lastError.message}`, "error");
          return;
        }
        if (!response?.success) {
          appendLog(`Pipeline error: ${response?.error || "Unknown error"}`, "error");
        } else {
          if (response.result?.cssRules) {
            cssEditor.value = response.result.cssRules;
          }
          if (response.result?.designDirection) {
            cssDirectionLabel.textContent = response.result.designDirection;
          }
          updatePinButtonUI(true);
          refreshSavedDesignsGallery();
          appendLog(`✓ Complete in ${secondsElapsed}s! Saved to gallery & pinned to site.`, "success");
        }
      }
    );
  }

  btnAutonomous.addEventListener("click", () => {
    promptInput.value = "";
    presetButtons.forEach((p) => p.classList.remove("active"));
    triggerPipeline("");
  });

  btnRun.addEventListener("click", () => {
    triggerPipeline(promptInput.value.trim());
  });

  btnCompare.addEventListener("click", async () => {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.id) return;

    chrome.tabs.sendMessage(tab.id, { action: "TOGGLE_PREVIEW" }, (res) => {
      if (chrome.runtime.lastError || !res || res.status === "NO_STYLES") {
        appendLog("No active redesign on this tab to compare yet.", "system");
        return;
      }
      updateCompareButtonUI(res.isPreviewDisabled);
      appendLog(
        res.isPreviewDisabled
          ? "Previewing Original Site (click Compare to restore redesign)."
          : "Showing Redesigned View.",
        "system"
      );
    });
  });

  btnRevert.addEventListener("click", async () => {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.id) return;

    chrome.tabs.sendMessage(tab.id, { action: "REVERT_ALL" }, () => {
      if (chrome.runtime.lastError) {
        appendLog("Nothing to revert or tab not ready.", "system");
      } else {
        resetChecklist();
        updateCompareButtonUI(false);
        updatePinButtonUI(false);
        appendLog("Original site state restored & site pin cleared.", "system");
      }
    });
  });

  function updatePinButtonUI(isEnforced) {
    currentTabEnforced = Boolean(isEnforced);
    if (!btnPinSite) return;
    if (currentTabEnforced) {
      btnPinSite.classList.add("enforced");
      btnPinSite.textContent = "📌 Enforced: ON";
    } else {
      btnPinSite.classList.remove("enforced");
      btnPinSite.textContent = "📌 Auto-Enforce: OFF";
    }
  }

  function refreshSavedDesignsGallery() {
    if (!savedDesignsList) return;
    chrome.storage.local.get(["savedDesignsLibrary"], (res) => {
      const all = Array.isArray(res?.savedDesignsLibrary) ? res.savedDesignsLibrary : [];
      if (designsCountEl) designsCountEl.textContent = String(all.length);

      let filtered = all;
      if (currentDesignFilter === "liked") {
        filtered = all.filter((d) => d.liked);
      } else if (currentDesignFilter === "site" && activeTabHostname) {
        filtered = all.filter((d) => d.hostname === activeTabHostname);
      }

      savedDesignsList.innerHTML = "";
      if (filtered.length === 0) {
        savedDesignsList.innerHTML = `<div class="empty-designs">${
          currentDesignFilter === "liked"
            ? "No ♥ liked designs yet. Click ♡ on any design to favorite it!"
            : currentDesignFilter === "site"
            ? `No designs saved for ${activeTabHostname || "this site"} yet.`
            : "No generated designs yet. Run a redesign above!"
        }</div>`;
        return;
      }

      filtered.forEach((d) => {
        const item = document.createElement("div");
        const isCurrent = cssEditor.value && d.cssRules === cssEditor.value;
        item.className = `saved-design-item${isCurrent ? " active-design" : ""}`;
        const swatches = d.swatches || ["#0b0f17", "#141a26", "#4ade80"];

        item.innerHTML = `
          <div class="design-swatches">
            <span class="design-swatch" style="background:${swatches[0]}"></span>
            <span class="design-swatch" style="background:${swatches[1]}"></span>
            <span class="design-swatch" style="background:${swatches[2]}"></span>
          </div>
          <div class="design-meta">
            <div class="design-title">${d.designDirection || "Saved Design"}</div>
            <div class="design-sub">${d.hostname || "universal"}</div>
          </div>
          <div class="design-item-actions">
            <button type="button" class="icon-btn like-toggle ${d.liked ? "liked" : ""}" title="Like / Favorite">${
              d.liked ? "♥" : "♡"
            }</button>
            <button type="button" class="icon-btn delete-design" title="Delete design">✕</button>
          </div>
        `;

        // Click card to smoothly transition active tab to this design & enforce it
        item.addEventListener("click", async (e) => {
          if (e.target.closest(".icon-btn")) return;
          cssEditor.value = d.cssRules;
          cssDirectionLabel.textContent = d.designDirection || "Saved Design";
          const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
          if (!tab?.id) return;
          chrome.tabs.sendMessage(
            tab.id,
            {
              action: "APPLY_REDESIGN",
              patch: {
                designId: d.id,
                designDirection: d.designDirection,
                cssRules: d.cssRules,
                domMutations: [],
                autoEnforce: true
              }
            },
            () => {
              updateCompareButtonUI(false);
              updatePinButtonUI(true);
              refreshSavedDesignsGallery();
              appendLog(`✦ Switched to "${(d.designDirection || "Saved Design").slice(0, 38)}"`, "success");
            }
          );
        });

        item.querySelector(".like-toggle").addEventListener("click", (e) => {
          e.stopPropagation();
          d.liked = !d.liked;
          chrome.storage.local.set({ savedDesignsLibrary: all }, () => {
            refreshSavedDesignsGallery();
          });
        });

        item.querySelector(".delete-design").addEventListener("click", (e) => {
          e.stopPropagation();
          const nextList = all.filter((entry) => entry.id !== d.id);
          chrome.storage.local.set({ savedDesignsLibrary: nextList }, () => {
            refreshSavedDesignsGallery();
          });
        });

        savedDesignsList.appendChild(item);
      });
    });
  }

  function updateCompareButtonUI(isPreviewDisabled) {
    if (isPreviewDisabled) {
      btnCompare.classList.add("active-compare");
      btnCompare.textContent = "Show New";
    } else {
      btnCompare.classList.remove("active-compare");
      btnCompare.textContent = "Compare";
    }
  }

  function updateStepUI(stepIndex, status, customDesc) {
    const stepEl = document.getElementById(`step-${stepIndex}`);
    if (!stepEl) return;

    stepEl.classList.remove("pending", "active", "completed", "waiting", "error");
    stepEl.classList.add(status);

    const descEl = stepEl.querySelector(".check-desc");
    if (customDesc && descEl) descEl.innerText = customDesc;

    chrome.storage.local.get(["agentRunState"], (res) => {
      const state = res.agentRunState || { isRunning: true, steps: {} };
      state.steps = state.steps || {};
      state.steps[stepIndex] = { status, desc: customDesc || descEl?.innerText };
      chrome.storage.local.set({ agentRunState: state });
    });
  }

  function appendLog(text, type = "action") {
    const entry = document.createElement("div");
    entry.className = `log-entry ${type}`;
    const timestamp = new Date().toLocaleTimeString([], { hour12: false });
    entry.innerText = `[${timestamp}] ${text}`;
    terminalLogs.appendChild(entry);
    terminalLogs.scrollTop = terminalLogs.scrollHeight;
  }

  function renderDynamicTodos(todos) {
    if (!checklistEl || !Array.isArray(todos) || todos.length === 0) return;
    checklistEl.innerHTML = "";
    todos.forEach((todo, idx) => {
      const stepNum = todo.id || idx + 1;
      const status = todo.status || "pending";
      const item = document.createElement("div");
      item.className = `check-item ${status}`;
      item.id = `step-${stepNum}`;

      const icon = document.createElement("div");
      icon.className = "check-icon";
      icon.textContent = String(stepNum);

      const content = document.createElement("div");
      content.className = "check-content";

      const title = document.createElement("div");
      title.className = "check-title";
      title.textContent = todo.title || `Task ${stepNum}`;

      const desc = document.createElement("div");
      desc.className = "check-desc";
      desc.textContent = todo.desc || "";

      content.appendChild(title);
      content.appendChild(desc);
      item.appendChild(icon);
      item.appendChild(content);
      checklistEl.appendChild(item);
    });
  }

  function resetChecklist() {
    if (checklistEl && defaultChecklistHTML) {
      checklistEl.innerHTML = defaultChecklistHTML;
    }
    for (let i = 1; i <= 4; i++) {
      const el = document.getElementById(`step-${i}`);
      if (el) el.className = "check-item pending";
    }
  }

  function formatTime(totalSeconds) {
    const mins = String(Math.floor(totalSeconds / 60)).padStart(2, "0");
    const secs = String(totalSeconds % 60).padStart(2, "0");
    return `${mins}:${secs}`;
  }

  function startTimer(initialSeconds = 0) {
    clearInterval(timerInterval);
    secondsElapsed = initialSeconds;
    timerDisplay.innerText = formatTime(secondsElapsed);
    timerInterval = setInterval(() => {
      secondsElapsed++;
      timerDisplay.innerText = formatTime(secondsElapsed);
    }, 1000);
  }

  function stopTimer() {
    clearInterval(timerInterval);
  }

  function setRunningState(isRunning) {
    btnRun.disabled = isRunning;
    btnAutonomous.disabled = isRunning;
    btnRun.style.opacity = isRunning ? "0.6" : "1.0";
    btnAutonomous.style.opacity = isRunning ? "0.6" : "1.0";
  }

  function restoreCockpitState(state) {
    if (Array.isArray(state.todos) && state.todos.length > 0) {
      renderDynamicTodos(state.todos);
      return;
    }
    if (state.steps) {
      Object.entries(state.steps).forEach(([step, data]) => {
        const stepEl = document.getElementById(`step-${step}`);
        if (!stepEl) return;
        stepEl.classList.remove("pending", "active", "completed", "waiting", "error");
        stepEl.classList.add(data.status);
        const descEl = stepEl.querySelector(".check-desc");
        if (data.desc && descEl) descEl.innerText = data.desc;
      });
    }
  }
}

if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", initPopup);
} else {
  initPopup();
}
