// content-script.js — Full-Page Semantic Stamping, Surface/Contrast Auto-Healer & Live Preview HUD

(() => {
  if (window.__redesigner_loaded) return;
  window.__redesigner_loaded = true;

  const originalPlacements = new Map();
  const appliedInlineClasses = [];
  const LOCAL_CACHE_KEY = "__redesigner_enforced_v2__";
  let isPreviewDisabled = false;
  let currentCSS = "";
  let currentDesignDirection = "";
  let currentDesignId = null;
  let isEnforcedOnSite = false;
  let hudHost = null;

  function getStyleContainer() {
    return document.head || document.documentElement;
  }

  function extractSwatches(cssText = "") {
    const bg = cssText.match(/--rd-bg\s*:\s*([^;!}]+)/i)?.[1]?.trim() || "#0b0f17";
    const surface = cssText.match(/--rd-surface\s*:\s*([^;!}]+)/i)?.[1]?.trim() || "#141a26";
    const accent = cssText.match(/--rd-accent\s*:\s*([^;!}]+)/i)?.[1]?.trim() || "#4ade80";
    return [bg, surface, accent];
  }

  /**
   * 0ms Pre-Paint Injection at document_start:
   * Reads synchronous localStorage cache BEFORE <body> exists so the browser never flashes the old design,
   * then syncs with chrome.storage.local and stamps the DOM as soon as it parses.
   */
  function bootstrapEnforcedDesignAtStart() {
    try {
      const rawCache = window.localStorage.getItem(LOCAL_CACHE_KEY);
      if (rawCache) {
        const cached = JSON.parse(rawCache);
        if (cached && cached.cssRules && cached.enabled !== false) {
          currentCSS = cached.cssRules;
          currentDesignDirection = cached.designDirection || "Enforced Design";
          currentDesignId = cached.id || null;
          isEnforcedOnSite = true;
          ensureBaseHealerStyles(true);
          injectRawStylesheet(currentCSS);
        }
      }
    } catch {
      // Ignore storage access errors in sandboxed iframes
    }

    // Also check chrome.storage.local for enforced design on this hostname
    const host = location.hostname;
    if (host && chrome?.storage?.local) {
      chrome.storage.local.get(["siteEnforcedDesigns"], (res) => {
        const map = res?.siteEnforcedDesigns || {};
        const enforced = map[host];
        if (enforced && enforced.cssRules && enforced.enabled !== false) {
          const changed = enforced.cssRules !== currentCSS;
          currentCSS = enforced.cssRules;
          currentDesignDirection = enforced.designDirection || "Enforced Design";
          currentDesignId = enforced.id || null;
          isEnforcedOnSite = true;
          try {
            window.localStorage.setItem(LOCAL_CACHE_KEY, JSON.stringify(enforced));
          } catch {}
          if (changed || !document.getElementById("redesigner-styles")) {
            ensureBaseHealerStyles(true);
            injectRawStylesheet(currentCSS);
          }
          if (document.body) {
            finalizeDomStampingAndHealing();
          }
        } else if (isEnforcedOnSite && (!enforced || enforced.enabled === false)) {
          // Was disabled in another tab/popup
          try {
            window.localStorage.removeItem(LOCAL_CACHE_KEY);
          } catch {}
          revertAllChanges(false);
        }
      });
    }

    const onDomReady = () => {
      if (currentCSS) {
        finalizeDomStampingAndHealing();
      }
    };

    if (document.readyState === "loading") {
      document.addEventListener("DOMContentLoaded", onDomReady, { once: true });
    } else {
      onDomReady();
    }

    window.addEventListener("load", () => {
      if (currentCSS) {
        finalizeDomStampingAndHealing();
      }
    }, { once: true });
  }

  function injectRawStylesheet(cssText) {
    const container = getStyleContainer();
    if (!container) return;
    let styleTag = document.getElementById("redesigner-styles");
    if (!styleTag) {
      styleTag = document.createElement("style");
      styleTag.id = "redesigner-styles";
      container.appendChild(styleTag);
    }
    styleTag.textContent = cssText || "";
    styleTag.disabled = isPreviewDisabled;
  }

  function finalizeDomStampingAndHealing() {
    if (!document.body || !currentCSS) return;
    analyzeAndStampPage();
    ensureBaseHealerStyles(false);
    injectRawStylesheet(currentCSS);
    autoHealPageContrast();
    mountOrUpdateFloatingHud();
  }

  bootstrapEnforcedDesignAtStart();

  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    try {
      switch (message.action) {
        case "PING":
          sendResponse({ status: "PONG", hasRedesign: Boolean(currentCSS) });
          return true;

        case "EXTRACT_SEMANTICS": {
          const siteGraph = analyzeAndStampPage();
          sendResponse({ status: "SUCCESS", data: siteGraph });
          return true;
        }

        case "INSPECT_DOM": {
          const inspection = inspectDomSelector(message.selector, message.limit || 8);
          sendResponse({ status: "SUCCESS", data: inspection });
          return true;
        }

        case "PROBE_ELEMENT": {
          const el =
            safeQuerySelector(message.selector) ||
            document.querySelector(`[data-rd-id="${CSS.escape(message.selector)}"]`);
          if (!el) {
            sendResponse({ data: { error: `Element ${message.selector} not found` } });
            return true;
          }
          const comp = window.getComputedStyle(el);
          const rect = el.getBoundingClientRect();
          const bgColor = getEffectiveBackgroundColor(el);
          const contrastRatio = computeContrastRatio(comp.color, bgColor);

          sendResponse({
            data: {
              id: el.dataset.rdId || null,
              role: el.dataset.rdRole || el.dataset.rdAffordance || null,
              tag: el.tagName.toLowerCase(),
              textSnippet: (el.innerText || "").trim().slice(0, 80),
              computed: {
                color: comp.color,
                backgroundColor: comp.backgroundColor,
                effectiveBackground: bgColor,
                contrastRatio: Number(contrastRatio.toFixed(2)),
                fontSize: comp.fontSize,
                fontWeight: comp.fontWeight,
                display: comp.display,
                position: comp.position,
                padding: comp.padding,
                borderRadius: comp.borderRadius
              },
              rect: {
                x: Math.round(rect.x),
                y: Math.round(rect.y),
                w: Math.round(rect.width),
                h: Math.round(rect.height)
              }
            }
          });
          return true;
        }

        case "VALIDATE_AFFORDANCES": {
          const validation = validateAffordancesAndContrast();
          sendResponse({ data: validation });
          return true;
        }

        case "APPLY_REDESIGN": {
          const healStats = applyDesignSystem(message.patch || {});
          sendResponse({
            status: "APPLIED",
            cssLength: currentCSS.length,
            isPreviewDisabled,
            healStats
          });
          return true;
        }

        case "TOGGLE_PREVIEW": {
          const styleTag = document.getElementById("redesigner-styles");
          const baseTag = document.getElementById("redesigner-base-healer");
          if (!styleTag) {
            sendResponse({ status: "NO_STYLES", isPreviewDisabled: false });
            return true;
          }
          isPreviewDisabled =
            typeof message.disabled === "boolean" ? message.disabled : !isPreviewDisabled;
          styleTag.disabled = isPreviewDisabled;
          if (baseTag) baseTag.disabled = isPreviewDisabled;
          updateHudState();
          sendResponse({ status: "TOGGLED", isPreviewDisabled });
          return true;
        }

        case "GET_CURRENT_STATE": {
          sendResponse({
            hasRedesign: Boolean(currentCSS),
            cssRules: currentCSS,
            designDirection: currentDesignDirection,
            designId: currentDesignId,
            isPreviewDisabled,
            isEnforcedOnSite,
            hostname: location.hostname
          });
          return true;
        }

        case "SET_ENFORCED_STATE": {
          setSiteEnforcement(Boolean(message.enforced));
          sendResponse({
            status: "UPDATED",
            isEnforcedOnSite
          });
          return true;
        }

        case "PREPARE_SCREENSHOT": {
          if (hudHost) hudHost.style.display = "none";
          sendResponse({ status: "READY" });
          return true;
        }

        case "GET_SCREENSHOT_PLAN": {
          const root = document.documentElement;
          const body = document.body;
          const height = Math.max(root?.scrollHeight || 0, body?.scrollHeight || 0);
          const viewport = Math.max(1, window.innerHeight || root?.clientHeight || 1);
          const maxY = Math.max(0, height - viewport);
          const step = Math.max(1, Math.floor(viewport * 0.82));
          const positions = [0];
          for (let y = step; y < maxY && positions.length < 4; y += step) positions.push(y);
          if (maxY > 0 && positions[positions.length - 1] !== maxY && positions.length < 4) positions.push(maxY);
          sendResponse({ positions, height, viewport, originalY: window.scrollY || 0 });
          return true;
        }

        case "SCROLL_SCREENSHOT_TO": {
          window.scrollTo({ top: Math.max(0, Number(message.y) || 0), behavior: "instant" });
          requestAnimationFrame(() => requestAnimationFrame(() => sendResponse({ y: window.scrollY || 0 })));
          return true;
        }

        case "RESTORE_SCREENSHOT_SCROLL": {
          window.scrollTo({ top: Math.max(0, Number(message.y) || 0), behavior: "instant" });
          sendResponse({ status: "RESTORED", y: window.scrollY || 0 });
          return true;
        }

        case "RESTORE_HUD": {
          if (hudHost && currentCSS) hudHost.style.display = "block";
          sendResponse({ status: "RESTORED" });
          return true;
        }

        case "REVERT_ALL": {
          revertAllChanges();
          sendResponse({ status: "REVERTED" });
          return true;
        }

        default:
          return false;
      }
    } catch (err) {
      sendResponse({ status: "ERROR", error: err.message });
      return true;
    }
  });

  function safeQuerySelector(selector) {
    if (!selector || typeof selector !== "string") return null;
    try {
      return document.querySelector(selector);
    } catch {
      return null;
    }
  }

  function inspectDomSelector(selector, limit = 8) {
    if (!selector || typeof selector !== "string") {
      return { error: "Missing selector string" };
    }
    let elements = [];
    try {
      elements = Array.from(document.querySelectorAll(selector));
    } catch {
      const byRdId = document.querySelector(`[data-rd-id="${CSS.escape(selector)}"]`);
      if (byRdId) elements = [byRdId];
    }

    if (elements.length === 0) {
      return { matchCount: 0, matches: [], note: `No elements matched "${selector}"` };
    }

    const matches = elements.slice(0, limit).map((el) => {
      const comp = window.getComputedStyle(el);
      const rect = el.getBoundingClientRect();
      const bg = getEffectiveBackgroundColor(el);
      const childSummary = Array.from(el.children)
        .slice(0, 8)
        .map((c) => {
          const tag = c.tagName.toLowerCase();
          const rd = c.dataset.rdId ? `[data-rd-id="${c.dataset.rdId}"]` : "";
          const role = c.dataset.rdRole ? `[data-rd-role="${c.dataset.rdRole}"]` : "";
          const cls =
            typeof c.className === "string" && c.className.trim()
              ? "." + c.className.trim().split(/\s+/).slice(0, 2).join(".")
              : "";
          return `${tag}${cls}${rd}${role}`;
        });

      return {
        tag: el.tagName.toLowerCase(),
        id: el.id || null,
        classes: typeof el.className === "string" ? el.className.trim() : "",
        rdId: el.dataset.rdId || null,
        rdRole: el.dataset.rdRole || el.dataset.rdAffordance || null,
        bounds: { w: Math.round(rect.width), h: Math.round(rect.height) },
        computed: {
          display: comp.display,
          color: comp.color,
          backgroundColor: comp.backgroundColor,
          effectiveBackground: bg,
          contrastRatio: Number(computeContrastRatio(comp.color, bg).toFixed(2)),
          border: comp.border,
          padding: comp.padding
        },
        childrenPreview: childSummary,
        textSnippet: (el.innerText || "").trim().replace(/\s+/g, " ").slice(0, 70)
      };
    });

    return {
      selector,
      matchCount: elements.length,
      matches
    };
  }

  function isVisible(el) {
    if (!el || !(el instanceof Element)) return false;
    if (el.id === "redesigner-hud-host") return false;
    const rect = el.getBoundingClientRect();
    const style = window.getComputedStyle(el);
    return (
      rect.width > 8 &&
      rect.height > 8 &&
      style.display !== "none" &&
      style.visibility !== "hidden" &&
      parseFloat(style.opacity || "1") > 0.05
    );
  }

  /**
   * Stamps the ENTIRE page with semantic [data-rd-role], [data-rd-affordance], and [data-rd-id]
   * so that CSS rules targeting [data-rd-role="..."] apply universally (even on pages with 30+ sections/lists),
   * while returning a concise summary for the LLM prompt.
   */
  function analyzeAndStampPage() {
    let idCounter = 0;
    const components = [];
    const affordances = [];
    const seenComponents = new Set();

    // 1. Tag major structural landmarks across the entire document
    const landmarks = [
      {
        role: "navbar",
        selector:
          "header, [role='banner'], nav:first-of-type, .navbar, .header, #header, #topban, .global-header"
      },
      {
        role: "sidebar",
        selector:
          "aside, [role='complementary'], .sidebar, #sidebar, .side-nav, #leftbar, #rightbar"
      },
      {
        role: "hero",
        selector: ".hero, .jumbotron, .banner, main > section:first-of-type"
      },
      {
        role: "main-content",
        selector: "main, [role='main'], article, #content, .content, #main, #center, #page-container"
      },
      {
        role: "section",
        selector:
          "main section, article section, .section, .col, .cats, .category-block, .widget, .panel, .box"
      },
      {
        role: "footer",
        selector: "footer, [role='contentinfo'], .footer, #footer"
      }
    ];

    landmarks.forEach(({ role, selector }) => {
      document.querySelectorAll(selector).forEach((el) => {
        if (!isVisible(el) || seenComponents.has(el)) return;
        seenComponents.add(el);

        const id =
          el.dataset.rdId && el.dataset.rdRole ? el.dataset.rdId : `rd-${role}-${++idCounter}`;
        el.dataset.rdId = id;
        el.dataset.rdRole = el.dataset.rdRole || role;

        // Include up to 16 representative landmarks in the LLM prompt summary
        if (components.length < 16) {
          const rect = el.getBoundingClientRect();
          const comp = window.getComputedStyle(el);
          components.push({
            id,
            role: el.dataset.rdRole,
            tag: el.tagName.toLowerCase(),
            selector: `[data-rd-id="${id}"]`,
            roleSelector: `[data-rd-role="${el.dataset.rdRole}"]`,
            childCount: el.children.length,
            bounds: `${Math.round(rect.width)}x${Math.round(rect.height)}`,
            bg: comp.backgroundColor,
            snippet: (el.innerText || "").trim().replace(/\s+/g, " ").slice(0, 60)
          });
        }
      });
    });

    // 2. Tag ALL homogeneous repeat cards, directory lists, and collection grids on the page
    let gridCount = 0;
    document.querySelectorAll("ul, ol, div, section, tbody").forEach((parent) => {
      if (!isVisible(parent)) return;
      const children = Array.from(parent.children).filter(isVisible);

      if (children.length >= 3) {
        const first = children[0].getBoundingClientRect();
        const sample = children.slice(1, Math.min(children.length, 6));
        const isHomogeneous = sample.every((c) => {
          const r = c.getBoundingClientRect();
          return Math.abs(r.width - first.width) < 55 && Math.abs(r.height - first.height) < 110;
        });

        // Stamp both card grids and directory link lists
        if (isHomogeneous && first.width > 55 && first.height >= 16) {
          gridCount++;
          const isDirectoryList = first.height < 42 && parent.matches("ul, ol, div");
          const gridRole = isDirectoryList ? "link-list" : "card-grid";
          const itemRole = isDirectoryList ? "list-item" : "card-item";

          const id = parent.dataset.rdId || `rd-${gridRole}-${gridCount}`;
          parent.dataset.rdId = id;
          if (!parent.dataset.rdRole || parent.dataset.rdRole === "section") {
            parent.dataset.rdRole = gridRole;
          }

          children.forEach((child, idx) => {
            child.dataset.rdId = child.dataset.rdId || `${id}-item-${idx + 1}`;
            if (!child.dataset.rdRole) {
              child.dataset.rdRole = itemRole;
            }
          });

          if (components.length < 22) {
            components.push({
              id,
              role: parent.dataset.rdRole,
              tag: parent.tagName.toLowerCase(),
              selector: `[data-rd-id="${id}"]`,
              roleSelector: `[data-rd-role="${parent.dataset.rdRole}"]`,
              itemSelector: `[data-rd-role="${itemRole}"]`,
              itemCount: children.length
            });
          }
        }
      }
    });

    // 3. Tag section headers / banners (e.g. .ban, h1-h5, th, caption)
    let headingCounter = 0;
    document.querySelectorAll("h1, h2, h3, h4, h5, .ban, .hdr, caption, th").forEach((el) => {
      if (!isVisible(el)) return;
      headingCounter++;
      if (!el.dataset.rdId) {
        el.dataset.rdId = `rd-heading-${headingCounter}`;
      }
      if (!el.dataset.rdRole) {
        el.dataset.rdRole = "section-header";
      }
    });

    // 4. Protect ALL functional affordances (Links, Search, Buttons, Inputs, Select, Tables)
    let affordanceCounter = 0;
    document
      .querySelectorAll(
        "button, a[href], input:not([type='hidden']), select, textarea, [role='button'], [role='search'], form"
      )
      .forEach((el) => {
        if (!isVisible(el)) return;
        const type = el.tagName.toLowerCase();
        let role = "interactive";

        if (
          type === "input" &&
          (el.type === "search" ||
            el.placeholder?.toLowerCase().includes("search") ||
            el.name?.toLowerCase().includes("q") ||
            el.name?.toLowerCase().includes("query") ||
            el.id?.toLowerCase().includes("search"))
        ) {
          role = "search-input";
        } else if (type === "form" || el.getAttribute("role") === "search") {
          role = "form-container";
        } else if (
          type === "button" ||
          el.getAttribute("role") === "button" ||
          el.type === "submit"
        ) {
          role = "action-cta";
        } else if (type === "a" && el.href) {
          role = "navigation-link";
        } else if (type === "input" || type === "select" || type === "textarea") {
          role = "form-control";
        }

        const id = el.dataset.rdId || `rd-affordance-${++affordanceCounter}`;
        el.dataset.rdId = id;
        el.dataset.rdAffordance = role;

        if (affordances.length < 35) {
          affordances.push({
            id,
            type,
            role,
            selector: `[data-rd-id="${id}"]`,
            label: (
              el.innerText ||
              el.placeholder ||
              el.value ||
              el.getAttribute("aria-label") ||
              ""
            )
              .trim()
              .replace(/\s+/g, " ")
              .slice(0, 60),
            disabled: Boolean(el.disabled),
            href: type === "a" ? el.getAttribute("href") : undefined,
            target: type === "a" ? el.getAttribute("target") : undefined,
            name: el.getAttribute("name") || undefined,
            inputType: type === "input" ? el.type : undefined,
            formAction: el.form?.getAttribute("action") || undefined,
            formMethod: el.form?.getAttribute("method") || undefined,
            ariaExpanded: el.getAttribute("aria-expanded") || undefined
          });
        }
      });

    if (!document.body) {
      return {
        title: document.title || "",
        url: location.hostname + location.pathname,
        viewport: { width: window.innerWidth, height: window.innerHeight },
        totalStampedGrids: 0,
        totalStampedAffordances: 0,
        currentDesignState: {},
        universalRoleSelectors: [],
        recognizedComponents: [],
        protectedAffordances: []
      };
    }

    const bodyStyle = window.getComputedStyle(document.body);
    const effectiveBg = getEffectiveBackgroundColor(document.body);

    // Compact accessibility/visual cartography: semantic summaries, never raw DOM dumps.
    const accessibleName = (el) => (
      el.getAttribute("aria-label") ||
      el.getAttribute("aria-labelledby") && el.getAttribute("aria-labelledby")
        .split(/\\s+/).map(id => document.getElementById(id)?.innerText || "").join(" ") ||
      el.getAttribute("alt") || el.getAttribute("title") ||
      el.innerText || el.value || el.placeholder || ""
    ).trim().replace(/\\s+/g, " ").slice(0, 100);

    const accessibilityMap = Array.from(document.querySelectorAll(
      "main,header,nav,aside,footer,section,article,h1,h2,h3,button,a[href],input:not([type=hidden]),select,textarea,[role]"
    )).filter(isVisible).slice(0, 140).map((el) => ({
      tag: el.tagName.toLowerCase(),
      role: el.getAttribute("role") || ({
        A: "link", BUTTON: "button", INPUT: "textbox", SELECT: "combobox",
        TEXTAREA: "textbox", NAV: "navigation", MAIN: "main", HEADER: "banner",
        FOOTER: "contentinfo", ASIDE: "complementary"
      }[el.tagName] || ""),
      name: accessibleName(el),
      level: /^H[1-6]$/.test(el.tagName) ? Number(el.tagName[1]) : undefined,
      expanded: el.getAttribute("aria-expanded"),
      state: el.disabled ? "disabled" : (el.getAttribute("aria-current") || ""),
      id: el.dataset.rdId || "",
      parent: el.parentElement?.dataset.rdId || ""
    }));

    const visualMap = Array.from(document.querySelectorAll(
      "header,nav,main,aside,section,article,footer,[data-rd-role]"
    )).filter(isVisible).slice(0, 70).map((el) => {
      const r = el.getBoundingClientRect();
      return {
        id: el.dataset.rdId || "",
        role: el.dataset.rdRole || el.tagName.toLowerCase(),
        x: Math.round(r.left + window.scrollX),
        y: Math.round(r.top + window.scrollY),
        width: Math.round(r.width),
        height: Math.round(r.height),
        fold: r.bottom <= window.innerHeight ? "above-fold" :
          (r.top < window.innerHeight ? "crosses-fold" : "below-fold")
      };
    });

    const pageMetrics = {
      documentWidth: Math.max(document.documentElement.scrollWidth, document.body.scrollWidth),
      documentHeight: Math.max(document.documentElement.scrollHeight, document.body.scrollHeight),
      viewportWidth: window.innerWidth,
      viewportHeight: window.innerHeight,
      scrollY: window.scrollY,
      landmarkCount: visualMap.length,
      accessibilityNodeCount: accessibilityMap.length
    };

    return {
      title: document.title,
      url: location.hostname + location.pathname,
      viewport: { width: window.innerWidth, height: window.innerHeight },
      totalStampedGrids: gridCount,
      totalStampedAffordances: affordanceCounter,
      currentDesignState: {
        background: effectiveBg || bodyStyle.backgroundColor,
        fontFamily: bodyStyle.fontFamily,
        color: bodyStyle.color,
        isDarkPage: isDarkColor(effectiveBg)
      },
      universalRoleSelectors: [
        '[data-rd-role="navbar"]',
        '[data-rd-role="sidebar"]',
        '[data-rd-role="hero"]',
        '[data-rd-role="main-content"]',
        '[data-rd-role="section"]',
        '[data-rd-role="section-header"]',
        '[data-rd-role="card-grid"]',
        '[data-rd-role="card-item"]',
        '[data-rd-role="link-list"]',
        '[data-rd-role="list-item"]',
        '[data-rd-role="footer"]',
        '[data-rd-affordance="action-cta"]',
        '[data-rd-affordance="search-input"]',
        '[data-rd-affordance="navigation-link"]',
        '[data-rd-affordance="form-control"]'
      ],
      recognizedComponents: components,
      protectedAffordances: affordances,
      accessibilityMap,
      visualMap,
      pageMetrics,
      preservationContract: {
        domReplacement: false,
        eventListenerIntrospection: "Not exposed by browser APIs; preserve by styling existing nodes in place",
        navigationAndForms: "Keep existing elements, attributes, handlers, hrefs, names and form actions unchanged"
      }
    };
  }

  /**
   * Deterministic Surface & WCAG Contrast Auto-Healer
   * Runs immediately after AI CSS injection to catch any unstamped legacy white containers
   * (on dark themes) or unreadable low-contrast links/text (< 3.8:1 WCAG ratio).
   */
  function autoHealPageContrast() {
    // Clear previous heal markers before re-evaluating
    document.querySelectorAll("[data-rd-healed-bg], [data-rd-healed-text]").forEach((el) => {
      delete el.dataset.rdHealedBg;
      delete el.dataset.rdHealedText;
    });

    const bodyBg = getEffectiveBackgroundColor(document.body);
    const pageIsDark = isDarkColor(bodyBg);
    let healedSurfaces = 0;
    let healedTexts = 0;

    // 1. Heal jarring legacy opaque white/light-gray boxes inside a dark theme redesign
    if (pageIsDark) {
      document
        .querySelectorAll(
          "div, section, article, aside, header, footer, nav, ul, ol, li, dl, dt, dd, table, tbody, thead, tr, td, th, form, fieldset, h1, h2, h3, h4, h5, h6"
        )
        .forEach((el) => {
          if (el.id === "redesigner-hud-host") return;
          const comp = window.getComputedStyle(el);
          const rgba = parseRgba(comp.backgroundColor);
          if (!rgba || rgba.a < 0.15) return;

          const lum = relativeLuminance(rgba);
          // If an element still has a legacy bright white/gray background (luminance > 0.65) in a dark theme
          if (lum > 0.65) {
            const isHeader = el.matches("h1, h2, h3, h4, h5, h6, th, [data-rd-role='section-header'], .ban");
            el.dataset.rdHealedBg = isHeader ? "elevated" : "surface";
            healedSurfaces++;
          }
        });
    } else {
      // In a light/editorial theme, heal any accidentally dark-on-dark containers if text is dark
      document.querySelectorAll("div, section, ul, li, table, td, th").forEach((el) => {
        if (el.id === "redesigner-hud-host") return;
        const comp = window.getComputedStyle(el);
        const rgba = parseRgba(comp.backgroundColor);
        const fg = parseRgba(comp.color);
        if (rgba && rgba.a > 0.5 && fg && relativeLuminance(rgba) < 0.12 && relativeLuminance(fg) < 0.2) {
          el.dataset.rdHealedBg = "light-surface";
          healedSurfaces++;
        }
      });
    }

    // 2. Heal any text or link elements whose WCAG contrast against their effective background is < 3.8:1
    document
      .querySelectorAll(
        "a, a span, a strong, a em, p, span, li, dt, dd, td, th, h1, h2, h3, h4, h5, h6, label, button, input, select, small, strong, b"
      )
      .forEach((el) => {
        if (el.id === "redesigner-hud-host") return;
        if (!isVisible(el)) return;

        // Check if element has direct text or is a link/button/input
        const hasDirectText = Array.from(el.childNodes).some(
          (n) => n.nodeType === Node.TEXT_NODE && n.textContent.trim().length > 0
        );
        if (!hasDirectText && !el.matches("a, button, input, select")) return;

        const comp = window.getComputedStyle(el);
        const bg = getEffectiveBackgroundColor(el);
        const ratio = computeContrastRatio(comp.color, bg);

        if (ratio < 3.8) {
          const bgDark = isDarkColor(bg);
          const isLink = el.tagName === "A" || Boolean(el.closest("a"));
          if (bgDark) {
            el.dataset.rdHealedText = isLink ? "dark-link" : "dark-fg";
          } else {
            el.dataset.rdHealedText = isLink ? "light-link" : "light-fg";
          }
          healedTexts++;
        }
      });

    return { pageIsDark, healedSurfaces, healedTexts };
  }

  function ensureBaseHealerStyles(isEarlyPrePaint = false) {
    const container = getStyleContainer();
    if (!container) return;
    let baseTag = document.getElementById("redesigner-base-healer");
    if (!baseTag) {
      baseTag = document.createElement("style");
      baseTag.id = "redesigner-base-healer";
      container.appendChild(baseTag);
    }

    baseTag.textContent = `
      :root {
        --rd-bg: #0b0f17;
        --rd-surface: #131924;
        --rd-surface-elevated: #1c2433;
        --rd-text: #f1f5f9;
        --rd-text-muted: #94a3b8;
        --rd-accent: #38bdf8;
        --rd-border: rgba(255, 255, 255, 0.08);
        --rd-radius: 10px;
      }

      /* Smooth transition between designs and during initial page load */
      html, body, [data-rd-role], [data-rd-id], [data-rd-healed-bg], a, button, input, select {
        transition: background-color 0.24s cubic-bezier(0.22, 1, 0.36, 1),
                    color 0.18s ease,
                    border-color 0.22s ease,
                    box-shadow 0.24s ease;
      }

      ${
        isEarlyPrePaint
          ? `html, body { background-color: var(--rd-bg, #0b0f17) !important; color: var(--rd-text, #f1f5f9) !important; }`
          : ""
      }

      /* Deterministic Auto-Healed Surfaces (fixes legacy opaque white boxes in dark mode) */
      [data-rd-healed-bg="surface"] {
        background-color: var(--rd-surface, #131924) !important;
        background-image: none !important;
        border-color: var(--rd-border, rgba(255, 255, 255, 0.08)) !important;
        color: var(--rd-text, #f1f5f9) !important;
      }

      [data-rd-healed-bg="elevated"] {
        background-color: var(--rd-surface-elevated, #1c2433) !important;
        background-image: none !important;
        border-color: var(--rd-border, rgba(255, 255, 255, 0.1)) !important;
        color: var(--rd-text, #ffffff) !important;
        border-radius: 6px !important;
        padding: 6px 10px !important;
      }

      [data-rd-healed-bg="light-surface"] {
        background-color: #ffffff !important;
        color: #111827 !important;
      }

      /* Deterministic Auto-Healed Typography & Links (guarantees WCAG AA/AAA readability) */
      [data-rd-healed-text="dark-fg"] {
        color: var(--rd-text, #f1f5f9) !important;
      }

      [data-rd-healed-text="dark-link"],
      [data-rd-healed-text="dark-link"]:visited,
      [data-rd-healed-text="dark-link"] * {
        color: var(--rd-accent, #7dd3fc) !important;
        text-decoration: none !important;
        transition: color 0.15s ease !important;
      }

      [data-rd-healed-text="dark-link"]:hover,
      [data-rd-healed-text="dark-link"]:hover * {
        color: #ffffff !important;
        text-decoration: underline !important;
      }

      [data-rd-healed-text="light-fg"] {
        color: #111827 !important;
      }

      [data-rd-healed-text="light-link"],
      [data-rd-healed-text="light-link"]:visited,
      [data-rd-healed-text="light-link"] * {
        color: #0284c7 !important;
      }
    `;
  }

  function validateAffordancesAndContrast() {
    const violations = [];
    const lowContrastElements = [];

    document.querySelectorAll("[data-rd-affordance]").forEach((el) => {
      const comp = window.getComputedStyle(el);
      const rect = el.getBoundingClientRect();
      if (
        rect.width < 4 ||
        rect.height < 4 ||
        comp.display === "none" ||
        comp.visibility === "hidden" ||
        parseFloat(comp.opacity || "1") < 0.1
      ) {
        violations.push({
          id: el.dataset.rdId,
          selector: `[data-rd-id="${el.dataset.rdId}"]`,
          role: el.dataset.rdAffordance,
          issue: "Interactive affordance collapsed or hidden"
        });
        return;
      }

      const text = (el.innerText || "").trim();
      if (text.length > 0) {
        const bg = getEffectiveBackgroundColor(el);
        const ratio = computeContrastRatio(comp.color, bg);
        if (ratio < 3.2) {
          lowContrastElements.push({
            id: el.dataset.rdId,
            selector: `[data-rd-id="${el.dataset.rdId}"]`,
            role: el.dataset.rdAffordance,
            textColor: comp.color,
            bgColor: bg,
            contrastRatio: Number(ratio.toFixed(2)),
            issue: `Low text contrast (${ratio.toFixed(1)}:1)`
          });
        }
      }
    });

    const totalIssues = violations.length + lowContrastElements.length;
    const score = Math.max(0, 100 - violations.length * 10 - lowContrastElements.length * 4);

    return {
      intact: violations.length === 0 && lowContrastElements.length === 0,
      score,
      violations: violations.slice(0, 10),
      lowContrastElements: lowContrastElements.slice(0, 10),
      totalIssues
    };
  }

  function parseRgba(colorStr) {
    if (!colorStr) return null;
    const m = colorStr.match(/rgba?\(\s*(\d+)[,\s]+(\d+)[,\s]+(\d+)(?:[,/\s]+([\d.]+))?\s*\)/i);
    if (!m) return null;
    return {
      r: Number(m[1]),
      g: Number(m[2]),
      b: Number(m[3]),
      a: m[4] !== undefined ? Number(m[4]) : 1
    };
  }

  function getEffectiveBackgroundColor(el) {
    let curr = el;
    while (curr && curr instanceof Element) {
      const bg = window.getComputedStyle(curr).backgroundColor;
      const rgba = parseRgba(bg);
      if (rgba && rgba.a > 0.15) {
        return `rgb(${rgba.r}, ${rgba.g}, ${rgba.b})`;
      }
      curr = curr.parentElement;
    }
    const htmlBg = window.getComputedStyle(document.documentElement).backgroundColor;
    const htmlRgba = parseRgba(htmlBg);
    if (htmlRgba && htmlRgba.a > 0.15) {
      return `rgb(${htmlRgba.r}, ${htmlRgba.g}, ${htmlRgba.b})`;
    }
    return "rgb(255, 255, 255)";
  }

  function relativeLuminance({ r, g, b }) {
    const normalize = (v) => {
      const s = v / 255;
      return s <= 0.03928 ? s / 12.92 : Math.pow((s + 0.055) / 1.055, 2.4);
    };
    return 0.2126 * normalize(r) + 0.7152 * normalize(g) + 0.0722 * normalize(b);
  }

  function computeContrastRatio(fgStr, bgStr) {
    const fg = parseRgba(fgStr) || { r: 0, g: 0, b: 0, a: 1 };
    const bg = parseRgba(bgStr) || { r: 255, g: 255, b: 255, a: 1 };
    const l1 = relativeLuminance(fg);
    const l2 = relativeLuminance(bg);
    const brightest = Math.max(l1, l2);
    const darkest = Math.min(l1, l2);
    return (brightest + 0.05) / (darkest + 0.05);
  }

  function isDarkColor(colorStr) {
    const rgb = parseRgba(colorStr);
    if (!rgb) return false;
    return relativeLuminance(rgb) < 0.28;
  }

  function setSiteEnforcement(enforced) {
    isEnforcedOnSite = Boolean(enforced && currentCSS);
    const host = location.hostname;
    if (!host) return;

    if (isEnforcedOnSite) {
      const payload = {
        id: currentDesignId || `design_${Date.now()}`,
        hostname: host,
        designDirection: currentDesignDirection || "Custom Design",
        cssRules: currentCSS,
        swatches: extractSwatches(currentCSS),
        enabled: true,
        updatedAt: Date.now()
      };
      try {
        window.localStorage.setItem(LOCAL_CACHE_KEY, JSON.stringify(payload));
      } catch {}
      chrome.storage.local.get(["siteEnforcedDesigns"], (res) => {
        const map = res?.siteEnforcedDesigns || {};
        map[host] = payload;
        chrome.storage.local.set({ siteEnforcedDesigns: map });
      });
    } else {
      try {
        window.localStorage.removeItem(LOCAL_CACHE_KEY);
      } catch {}
      chrome.storage.local.get(["siteEnforcedDesigns"], (res) => {
        const map = res?.siteEnforcedDesigns || {};
        delete map[host];
        chrome.storage.local.set({ siteEnforcedDesigns: map });
      });
    }
    updateHudState();
  }

  function applyDesignSystem(patch) {
    const container = getStyleContainer();
    if (!container) return { healedSurfaces: 0, healedTexts: 0 };

    if (document.body) {
      analyzeAndStampPage();
    }
    ensureBaseHealerStyles(false);

    let styleTag = document.getElementById("redesigner-styles");
    if (!styleTag) {
      styleTag = document.createElement("style");
      styleTag.id = "redesigner-styles";
      container.appendChild(styleTag);
    }

    if (typeof patch.cssRules === "string") {
      currentCSS = patch.cssRules;
      styleTag.textContent = patch.cssRules;
    }
    if (patch.designDirection) {
      currentDesignDirection = patch.designDirection;
    }
    if (patch.designId) {
      currentDesignId = patch.designId;
    }

    isPreviewDisabled = false;
    styleTag.disabled = false;
    const baseTag = document.getElementById("redesigner-base-healer");
    if (baseTag) baseTag.disabled = false;

    if (Array.isArray(patch.domMutations) && document.body) {
      patch.domMutations.forEach((mut) => {
        if (!mut || !mut.sourceId) return;
        const source =
          document.querySelector(`[data-rd-id="${CSS.escape(mut.sourceId)}"]`) ||
          safeQuerySelector(mut.sourceId);
        if (!source) return;

        if (mut.action === "reparent" && mut.targetId) {
          const target =
            document.querySelector(`[data-rd-id="${CSS.escape(mut.targetId)}"]`) ||
            safeQuerySelector(mut.targetId);

          if (
            target &&
            source !== target &&
            !source.contains(target) &&
            source !== document.body &&
            source !== document.documentElement
          ) {
            if (!originalPlacements.has(source)) {
              originalPlacements.set(source, {
                parent: source.parentNode,
                nextSibling: source.nextSibling
              });
            }
            try {
              if (mut.position === "prepend") {
                target.insertBefore(source, target.firstChild);
              } else {
                target.appendChild(source);
              }
            } catch {
              // Ignore invalid DOM hierarchy moves
            }
          }
        } else if (mut.action === "addClass" && mut.className) {
          source.classList.add(mut.className);
          appliedInlineClasses.push({ el: source, className: mut.className });
        }
      });
    }

    // Automatically enforce newly applied designs on this site so page navigations don't lose the design
    if (patch.autoEnforce !== false && currentCSS.trim().length > 0) {
      setSiteEnforcement(true);
    }

    const healStats = document.body
      ? autoHealPageContrast()
      : { healedSurfaces: 0, healedTexts: 0 };

    if (currentCSS.trim().length > 0 && document.body) {
      mountOrUpdateFloatingHud();
    }

    return healStats;
  }

  function mountOrUpdateFloatingHud() {
    if (!document.body) return;
    if (!hudHost) {
      hudHost = document.createElement("div");
      hudHost.id = "redesigner-hud-host";
      hudHost.style.cssText =
        "position: fixed; bottom: 18px; right: 18px; z-index: 2147483647; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;";
      const shadow = hudHost.attachShadow({ mode: "open" });

      shadow.innerHTML = `
        <style>
          .hud-wrapper {
            position: relative;
            display: flex;
            flex-direction: column;
            align-items: flex-end;
            gap: 8px;
          }
          .designs-popover {
            width: 310px;
            max-height: 310px;
            background: rgba(11, 17, 19, 0.96);
            backdrop-filter: blur(16px);
            -webkit-backdrop-filter: blur(16px);
            border: 1px solid rgba(74, 222, 128, 0.35);
            border-radius: 14px;
            box-shadow: 0 16px 40px rgba(0, 0, 0, 0.6);
            padding: 12px;
            color: #f3f6f5;
            display: none;
            flex-direction: column;
            gap: 8px;
          }
          .designs-popover.open {
            display: flex;
          }
          .popover-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-size: 11px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.06em;
            color: #86efac;
            padding-bottom: 6px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.08);
          }
          .popover-tabs {
            display: flex;
            gap: 4px;
          }
          .tab-btn {
            background: rgba(255, 255, 255, 0.06);
            border: 1px solid rgba(255, 255, 255, 0.1);
            color: #94a3b8;
            font-size: 10px;
            padding: 3px 8px;
            border-radius: 999px;
            cursor: pointer;
          }
          .tab-btn.active {
            background: #4ade80;
            color: #052e16;
            border-color: #4ade80;
            font-weight: 700;
          }
          .design-list {
            display: flex;
            flex-direction: column;
            gap: 6px;
            overflow-y: auto;
            max-height: 220px;
            padding-right: 2px;
          }
          .design-card {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 8px;
            padding: 8px 10px;
            border-radius: 9px;
            background: rgba(255, 255, 255, 0.04);
            border: 1px solid rgba(255, 255, 255, 0.08);
            cursor: pointer;
            transition: all 0.15s ease;
          }
          .design-card:hover {
            background: rgba(74, 222, 128, 0.12);
            border-color: rgba(74, 222, 128, 0.45);
          }
          .design-card.active {
            border-color: #4ade80;
            background: rgba(74, 222, 128, 0.15);
          }
          .swatches {
            display: flex;
            gap: 3px;
            flex-shrink: 0;
          }
          .swatch {
            width: 11px;
            height: 11px;
            border-radius: 50%;
            border: 1px solid rgba(255, 255, 255, 0.25);
          }
          .card-info {
            flex: 1;
            min-width: 0;
          }
          .card-title {
            font-size: 11.5px;
            font-weight: 600;
            color: #f1f5f9;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
          }
          .card-meta {
            font-size: 9.5px;
            color: #64748b;
          }
          .card-actions {
            display: flex;
            gap: 4px;
            align-items: center;
          }
          .like-btn {
            background: transparent;
            border: none;
            color: #64748b;
            font-size: 13px;
            padding: 2px 5px;
            cursor: pointer;
          }
          .like-btn.liked {
            color: #f43f5e;
          }
          .empty-note {
            font-size: 11px;
            color: #64748b;
            text-align: center;
            padding: 14px 6px;
          }
          .hud-pill {
            display: flex;
            align-items: center;
            gap: 6px;
            background: rgba(13, 19, 20, 0.92);
            backdrop-filter: blur(12px);
            -webkit-backdrop-filter: blur(12px);
            border: 1px solid rgba(74, 222, 128, 0.35);
            box-shadow: 0 10px 28px rgba(0, 0, 0, 0.45);
            padding: 6px 10px;
            border-radius: 999px;
            color: #f3f6f5;
            font-size: 12px;
            user-select: none;
            transition: all 0.2s ease;
          }
          .badge {
            width: 8px;
            height: 8px;
            border-radius: 50%;
            background: #4ade80;
            box-shadow: 0 0 8px #4ade80;
          }
          .badge.paused {
            background: #fbbf24;
            box-shadow: 0 0 8px #fbbf24;
          }
          .label {
            font-weight: 600;
            font-size: 11px;
            color: #e2e8f0;
            max-width: 135px;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
          }
          button {
            background: rgba(255, 255, 255, 0.08);
            border: 1px solid rgba(255, 255, 255, 0.12);
            color: #f8fafc;
            border-radius: 999px;
            padding: 4px 8px;
            font-size: 10.5px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.15s ease;
          }
          button:hover {
            background: rgba(74, 222, 128, 0.2);
            border-color: #4ade80;
            color: #fff;
          }
          button.pin-active {
            background: rgba(74, 222, 128, 0.2);
            border-color: #4ade80;
            color: #86efac;
          }
          button.liked-pill {
            color: #fb7185;
            border-color: rgba(244, 63, 94, 0.4);
          }
          button.close-btn {
            padding: 4px 6px;
            color: #94a3b8;
            border-color: transparent;
            background: transparent;
          }
          button.close-btn:hover {
            color: #f87171;
          }
        </style>
        <div class="hud-wrapper">
          <div class="designs-popover" id="hud-popover">
            <div class="popover-header">
              <span>Saved &amp; Liked Designs</span>
              <div class="popover-tabs">
                <button type="button" class="tab-btn active" data-filter="all">All</button>
                <button type="button" class="tab-btn" data-filter="liked">♥ Liked</button>
              </div>
            </div>
            <div class="design-list" id="hud-design-list"></div>
          </div>

          <div class="hud-pill">
            <span class="badge" id="hud-badge"></span>
            <span class="label" id="hud-label">ReDesigner Active</span>
            <button type="button" id="hud-designs-btn" title="Choose from generated or liked designs">✦ Designs</button>
            <button type="button" id="hud-like-btn" title="Like / Save this design">♡</button>
            <button type="button" id="hud-pin-btn" title="Enforce & auto-load this design on this site before page render">📌 Enforced</button>
            <button type="button" id="hud-toggle" title="Toggle Before / After">Compare</button>
            <button type="button" id="hud-revert" title="Revert to Original">Revert</button>
            <button type="button" class="close-btn" id="hud-dismiss" title="Hide toolbar">✕</button>
          </div>
        </div>
      `;

      let currentFilter = "all";
      const popover = shadow.getElementById("hud-popover");
      const designListEl = shadow.getElementById("hud-design-list");
      const tabBtns = shadow.querySelectorAll(".tab-btn");

      const refreshPopoverList = () => {
        chrome.storage.local.get(["savedDesignsLibrary"], (res) => {
          const all = Array.isArray(res?.savedDesignsLibrary) ? res.savedDesignsLibrary : [];
          const filtered =
            currentFilter === "liked" ? all.filter((d) => d.liked) : all;

          designListEl.innerHTML = "";
          if (filtered.length === 0) {
            designListEl.innerHTML = `<div class="empty-note">${
              currentFilter === "liked"
                ? "No liked designs yet. Click ♡ to save favorites!"
                : "Generated designs will appear here."
            }</div>`;
            return;
          }

          filtered.forEach((d) => {
            const card = document.createElement("div");
            card.className = `design-card${d.cssRules === currentCSS ? " active" : ""}`;
            const swatches = d.swatches || extractSwatches(d.cssRules);

            card.innerHTML = `
              <div class="swatches">
                <span class="swatch" style="background:${swatches[0]}"></span>
                <span class="swatch" style="background:${swatches[1]}"></span>
                <span class="swatch" style="background:${swatches[2]}"></span>
              </div>
              <div class="card-info">
                <div class="card-title">${d.designDirection || "Custom Design"}</div>
                <div class="card-meta">${d.hostname || "universal"}</div>
              </div>
              <div class="card-actions">
                <button type="button" class="like-btn ${d.liked ? "liked" : ""}" title="Toggle Like">${
                  d.liked ? "♥" : "♡"
                }</button>
              </div>
            `;

            card.addEventListener("click", (e) => {
              if (e.target.closest(".like-btn")) return;
              applyDesignSystem({
                designId: d.id,
                designDirection: d.designDirection,
                cssRules: d.cssRules,
                domMutations: [],
                autoEnforce: true
              });
              refreshPopoverList();
            });

            card.querySelector(".like-btn").addEventListener("click", (e) => {
              e.stopPropagation();
              d.liked = !d.liked;
              chrome.storage.local.set({ savedDesignsLibrary: all }, () => {
                refreshPopoverList();
                updateHudState();
              });
            });

            designListEl.appendChild(card);
          });
        });
      };

      tabBtns.forEach((btn) => {
        btn.addEventListener("click", () => {
          tabBtns.forEach((b) => b.classList.remove("active"));
          btn.classList.add("active");
          currentFilter = btn.dataset.filter;
          refreshPopoverList();
        });
      });

      shadow.getElementById("hud-designs-btn").addEventListener("click", () => {
        popover.classList.toggle("open");
        if (popover.classList.contains("open")) {
          refreshPopoverList();
        }
      });

      shadow.getElementById("hud-like-btn").addEventListener("click", () => {
        if (!currentCSS) return;
        chrome.storage.local.get(["savedDesignsLibrary"], (res) => {
          const all = Array.isArray(res?.savedDesignsLibrary) ? res.savedDesignsLibrary : [];
          let existing = all.find(
            (d) => (currentDesignId && d.id === currentDesignId) || d.cssRules === currentCSS
          );
          if (existing) {
            existing.liked = !existing.liked;
          } else {
            existing = {
              id: currentDesignId || `design_${Date.now()}`,
              hostname: location.hostname,
              designDirection: currentDesignDirection || "Saved Design",
              cssRules: currentCSS,
              swatches: extractSwatches(currentCSS),
              liked: true,
              createdAt: Date.now()
            };
            all.unshift(existing);
          }
          chrome.storage.local.set({ savedDesignsLibrary: all.slice(0, 35) }, () => {
            updateHudState();
            if (popover.classList.contains("open")) refreshPopoverList();
          });
        });
      });

      shadow.getElementById("hud-pin-btn").addEventListener("click", () => {
        setSiteEnforcement(!isEnforcedOnSite);
      });

      shadow.getElementById("hud-toggle").addEventListener("click", () => {
        const styleTag = document.getElementById("redesigner-styles");
        const baseTag = document.getElementById("redesigner-base-healer");
        if (!styleTag) return;
        isPreviewDisabled = !isPreviewDisabled;
        styleTag.disabled = isPreviewDisabled;
        if (baseTag) baseTag.disabled = isPreviewDisabled;
        updateHudState();
      });

      shadow.getElementById("hud-revert").addEventListener("click", () => {
        revertAllChanges(true);
      });

      shadow.getElementById("hud-dismiss").addEventListener("click", () => {
        hudHost.style.display = "none";
      });

      document.body.appendChild(hudHost);
    }

    hudHost.style.display = "block";
    updateHudState();
  }

  function updateHudState() {
    if (!hudHost || !hudHost.shadowRoot) return;
    const badge = hudHost.shadowRoot.getElementById("hud-badge");
    const label = hudHost.shadowRoot.getElementById("hud-label");
    const toggleBtn = hudHost.shadowRoot.getElementById("hud-toggle");
    const pinBtn = hudHost.shadowRoot.getElementById("hud-pin-btn");
    const likeBtn = hudHost.shadowRoot.getElementById("hud-like-btn");

    if (pinBtn) {
      if (isEnforcedOnSite) {
        pinBtn.classList.add("pin-active");
        pinBtn.textContent = "📌 Enforced";
      } else {
        pinBtn.classList.remove("pin-active");
        pinBtn.textContent = "📌 Pin Site";
      }
    }

    if (likeBtn && chrome?.storage?.local) {
      chrome.storage.local.get(["savedDesignsLibrary"], (res) => {
        const all = Array.isArray(res?.savedDesignsLibrary) ? res.savedDesignsLibrary : [];
        const match = all.find(
          (d) => (currentDesignId && d.id === currentDesignId) || d.cssRules === currentCSS
        );
        if (match?.liked) {
          likeBtn.textContent = "♥";
          likeBtn.classList.add("liked-pill");
        } else {
          likeBtn.textContent = "♡";
          likeBtn.classList.remove("liked-pill");
        }
      });
    }

    if (isPreviewDisabled) {
      badge?.classList.add("paused");
      if (label) label.textContent = "Original View";
      if (toggleBtn) toggleBtn.textContent = "Show Redesign";
    } else {
      badge?.classList.remove("paused");
      if (label) label.textContent = currentDesignDirection || "ReDesigner Active";
      if (toggleBtn) toggleBtn.textContent = "Compare";
    }
  }

  function revertAllChanges(clearSiteEnforcement = true) {
    if (clearSiteEnforcement) {
      setSiteEnforcement(false);
    }
    document.getElementById("redesigner-styles")?.remove();
    document.getElementById("redesigner-base-healer")?.remove();
    document.getElementById("redesigner-critic-styles")?.remove();
    currentCSS = "";
    currentDesignDirection = "";
    currentDesignId = null;
    isPreviewDisabled = false;

    if (hudHost) {
      hudHost.remove();
      hudHost = null;
    }

    originalPlacements.forEach((placement, node) => {
      if (placement.parent) {
        try {
          placement.parent.insertBefore(node, placement.nextSibling);
        } catch {
          // Ignore if parent detached
        }
      }
    });
    originalPlacements.clear();

    while (appliedInlineClasses.length > 0) {
      const item = appliedInlineClasses.pop();
      item.el?.classList?.remove(item.className);
    }

    document
      .querySelectorAll("[data-rd-id], [data-rd-healed-bg], [data-rd-healed-text]")
      .forEach((el) => {
        delete el.dataset.rdId;
        delete el.dataset.rdRole;
        delete el.dataset.rdAffordance;
        delete el.dataset.rdHealedBg;
        delete el.dataset.rdHealedText;
      });
  }
})();
