// agent-runtime.js — Autonomous Workspace Agent with Todo Planning, Native Function Calling & SSE Streaming

export class AgentRuntime {
  constructor({ tabId, provider, model, apiKey, isVision, onStatus, onStep, onTodos }) {
    this.tabId = tabId;
    this.provider = provider;
    this.model = model;
    this.apiKey = apiKey;
    this.isVision = Boolean(isVision);
    this.onStatus = onStatus || (() => {});
    this.onStep = onStep || (() => {});
    this.onTodos = onTodos || (() => {});

    // Virtual Workspace Filesystem
    this.workspace = {
      "todos.json": "[]",
      "design-spec.json": "",
      "styles.css": "",
      "mutations.json": "[]"
    };

    this.todos = [];
    this.checkpoints = [];
    this.currentCheckpointId = 0;

    // Conversation memories
    this.history = []; // OpenAI / Groq / OpenRouter format
    this.geminiContents = []; // Native Gemini Content[] format (preserves thoughtSignature & functionCall)
    this.systemPrompt = "";
    this.preferredGeminiModel = null;
    this.observationCount = 0;
    this.lastRenderedCss = "";
    this.lastValidation = null;
    this.lastScreenshotAttached = false;
    this.applyCount = 0;
    this.refinementCount = 0;
  }

  /**
   * Native Gemini FunctionDeclarations Schema (OpenAPI 3.0 subset for v1beta generateContent / streamGenerateContent)
   */
  getGeminiFunctionDeclarations() {
    return [
      {
        name: "manage_todos",
        description:
          "Create or update your structured Todo list. Call this FIRST to plan your tasks, and call it as you progress to mark tasks 'in_progress' or 'completed'.",
        parameters: {
          type: "OBJECT",
          properties: {
            todos: {
              type: "ARRAY",
              description: "Complete ordered list of 4 to 6 todo items for the redesign task.",
              items: {
                type: "OBJECT",
                properties: {
                  id: { type: "INTEGER", description: "1-based step number (1, 2, 3...)" },
                  title: { type: "STRING", description: "Short action title (max 45 chars)" },
                  status: {
                    type: "STRING",
                    enum: ["pending", "in_progress", "completed"]
                  },
                  detail: {
                    type: "STRING",
                    description: "Brief status detail or what is being done in this step"
                  }
                },
                required: ["id", "title", "status", "detail"]
              }
            }
          },
          required: ["todos"]
        }
      },
      {
        name: "inspect_dom",
        description:
          "Query the live webpage DOM using any CSS selector or [data-rd-role] to inspect actual tags, classes, child elements, and computed colors before writing CSS.",
        parameters: {
          type: "OBJECT",
          properties: {
            selector: {
              type: "STRING",
              description:
                "CSS selector to inspect, e.g. '[data-rd-role=\"section\"]', 'header, nav', or '#center'"
            },
            limit: {
              type: "INTEGER",
              description: "Max elements to return (default 6)"
            }
          },
          required: ["selector"]
        }
      },
      {
        name: "probe_element",
        description:
          "Deep-inspect computed styles, effective background color, bounding box, and WCAG contrast ratio for a single element.",
        parameters: {
          type: "OBJECT",
          properties: {
            selector: {
              type: "STRING",
              description: "CSS selector or data-rd-id value"
            }
          },
          required: ["selector"]
        }
      },
      {
        name: "read_file",
        description:
          "Read a file from your workspace ('todos.json', 'design-spec.json', 'styles.css', 'mutations.json') with line numbers.",
        parameters: {
          type: "OBJECT",
          properties: {
            filename: {
              type: "STRING",
              enum: ["todos.json", "design-spec.json", "styles.css", "mutations.json"]
            }
          },
          required: ["filename"]
        }
      },
      {
        name: "write_file",
        description:
          "Create or overwrite a file in your workspace ('design-spec.json', 'styles.css', 'mutations.json').",
        parameters: {
          type: "OBJECT",
          properties: {
            filename: {
              type: "STRING",
              enum: ["design-spec.json", "styles.css", "mutations.json"]
            },
            content: {
              type: "STRING",
              description: "Full file content to write."
            }
          },
          required: ["filename", "content"]
        }
      },
      {
        name: "edit_file",
        description:
          "Surgically edit 'styles.css' or 'design-spec.json' by replacing old_text with new_text, or appending new CSS rules at the end of the file without rewriting the whole file.",
        parameters: {
          type: "OBJECT",
          properties: {
            filename: {
              type: "STRING",
              enum: ["styles.css", "design-spec.json"]
            },
            old_text: {
              type: "STRING",
              description: "Exact text to replace (leave empty if only appending via append_text)"
            },
            new_text: {
              type: "STRING",
              description: "Replacement text for old_text"
            },
            append_text: {
              type: "STRING",
              description: "Additional CSS rules to append to the end of the file"
            }
          },
          required: ["filename"]
        }
      },
      {
        name: "apply_and_render",
        description:
          "Inject current workspace 'styles.css' and 'mutations.json' into the live browser tab and run the surface/contrast normalizer.",
        parameters: {
          type: "OBJECT",
          properties: {}
        }
      },
      {
        name: "run_validation",
        description:
          "Run the WCAG Contrast & Affordance Sentinel on the live tab to get a 0-100 quality score and identify any remaining low-contrast or hidden elements.",
        parameters: {
          type: "OBJECT",
          properties: {}
        }
      },
      {
        name: "take_screenshot",
        description:
          "Capture a live visual screenshot of the webpage after rendering so you can visually critique layout, alignment, and contrast.",
        parameters: {
          type: "OBJECT",
          properties: {}
        }
      },
      {
        name: "commit_checkpoint",
        description: "Save a workspace snapshot before making experimental changes.",
        parameters: {
          type: "OBJECT",
          properties: {
            description: { type: "STRING" }
          },
          required: ["description"]
        }
      },
      {
        name: "undo_change",
        description: "Revert workspace and live tab to a previous checkpoint ID.",
        parameters: {
          type: "OBJECT",
          properties: {
            checkpointId: { type: "INTEGER" }
          },
          required: ["checkpointId"]
        }
      },
      {
        name: "finish_task",
        description:
          "Mark all todos complete and finish the redesign session once styles are rendered and validated.",
        parameters: {
          type: "OBJECT",
          properties: {
            summary: {
              type: "STRING",
              description: "Concise summary of the completed redesign and visual improvements."
            }
          },
          required: ["summary"]
        }
      }
    ];
  }

  /**
   * OpenAI / Groq / OpenRouter Function Calling Schema
   */
  getOpenAIToolsSchema() {
    return this.getGeminiFunctionDeclarations().map((fn) => ({
      type: "function",
      function: {
        name: fn.name,
        description: fn.description,
        parameters: this.convertSchemaToLowercase(fn.parameters)
      }
    }));
  }

  convertSchemaToLowercase(schema) {
    if (!schema || typeof schema !== "object") return schema;
    const out = { ...schema };
    if (typeof out.type === "string") {
      out.type = out.type.toLowerCase();
    }
    if (out.properties) {
      out.properties = {};
      for (const [k, v] of Object.entries(schema.properties)) {
        out.properties[k] = this.convertSchemaToLowercase(v);
      }
    }
    if (out.items) {
      out.items = this.convertSchemaToLowercase(schema.items);
    }
    return out;
  }

  /**
   * Execute a workspace or browser tool
   */
  async executeTool(name, args = {}) {
    switch (name) {
      case "manage_todos": {
        if (Array.isArray(args.todos) && args.todos.length > 0) {
          this.todos = args.todos.map((t, idx) => ({
            id: t.id || idx + 1,
            title: t.title || `Task ${idx + 1}`,
            status:
              t.status === "in_progress"
                ? "active"
                : t.status === "completed"
                ? "completed"
                : "pending",
            desc: t.detail || ""
          }));
          this.workspace["todos.json"] = JSON.stringify(this.todos, null, 2);
          this.onTodos(this.todos);

          const activeTodo = this.todos.find((t) => t.status === "active");
          const doneCount = this.todos.filter((t) => t.status === "completed").length;
          this.onStatus(
            `Todo Plan [${doneCount}/${this.todos.length} done]${
              activeTodo ? ` → Active: ${activeTodo.title}` : ""
            }`
          );
        }
        return {
          status: "todos_updated",
          total: this.todos.length,
          completed: this.todos.filter((t) => t.status === "completed").length
        };
      }

      case "inspect_dom": {
        this.onStatus(`Tool → inspect_dom("${args.selector}")`);
        const res = await chrome.tabs.sendMessage(this.tabId, {
          action: "INSPECT_DOM",
          selector: args.selector,
          limit: args.limit || 6
        });
        return res?.data || { error: "Could not inspect selector" };
      }

      case "probe_element": {
        this.onStatus(`Tool → probe_element("${args.selector}")`);
        const res = await chrome.tabs.sendMessage(this.tabId, {
          action: "PROBE_ELEMENT",
          selector: args.selector
        });
        return res?.data || { error: "Element not found" };
      }

      case "read_file": {
        this.onStatus(`Tool → read_file("${args.filename}")`);
        const raw = this.workspace[args.filename] || "";
        if (!raw) return `[File ${args.filename} is empty]`;
        const numbered = String(raw)
          .split("\n")
          .map((line, i) => `${String(i + 1).padStart(4, " ")}\t${line}`)
          .join("\n");
        return numbered;
      }

      case "write_file": {
        const content =
          typeof args.content === "string" ? args.content : JSON.stringify(args.content, null, 2);
        this.workspace[args.filename] = content;
        this.onStatus(`Tool → write_file("${args.filename}", ${content.length} bytes)`);
        return { status: "success", filename: args.filename, bytesWritten: content.length };
      }

      case "edit_file": {
        const filename = args.filename || "styles.css";
        let current = String(this.workspace[filename] || "");
        let actionTaken = "none";

        if (args.old_text && current.includes(args.old_text)) {
          current = current.replace(args.old_text, args.new_text || "");
          actionTaken = "replaced";
        } else if (args.new_text && !args.old_text) {
          current = `${current}\n${args.new_text}`;
          actionTaken = "appended_new_text";
        }

        if (args.append_text) {
          current = `${current}\n\n/* Appended Refinement */\n${args.append_text}`;
          actionTaken = actionTaken === "replaced" ? "replaced_and_appended" : "appended";
        }

        this.workspace[filename] = current;
        this.onStatus(`Tool → edit_file("${filename}", ${actionTaken}, total ${current.length}B)`);
        return {
          status: "success",
          filename,
          actionTaken,
          totalBytes: current.length
        };
      }

      case "apply_and_render": {
        this.onStatus("Tool → apply_and_render() injecting workspace into live page...");
        let mutations = [];
        try {
          mutations =
            typeof this.workspace["mutations.json"] === "string"
              ? JSON.parse(this.workspace["mutations.json"] || "[]")
              : this.workspace["mutations.json"] || [];
        } catch {
          mutations = [];
        }

        let designDirection = "Autonomous Workspace Redesign";
        try {
          const spec =
            typeof this.workspace["design-spec.json"] === "string" &&
            this.workspace["design-spec.json"].trim()
              ? JSON.parse(this.workspace["design-spec.json"])
              : null;
          if (spec?.designDirection || spec?.theme) {
            designDirection = spec.designDirection || spec.theme;
          }
        } catch {
          // ignore
        }

        const applyRes = await chrome.tabs.sendMessage(this.tabId, {
          action: "APPLY_REDESIGN",
          patch: {
            designDirection,
            cssRules: this.workspace["styles.css"] || "",
            domMutations: Array.isArray(mutations) ? mutations : []
          }
        });
        await new Promise((r) => setTimeout(r, 380));

        const healStats = applyRes?.healStats || {};
        if (healStats.healedSurfaces || healStats.healedTexts) {
          this.onStatus(
            `Auto-Healer normalized ${healStats.healedSurfaces || 0} legacy surfaces & ${
              healStats.healedTexts || 0
            } text/link contrast nodes.`
          );
        }

        const renderedCss = this.workspace["styles.css"] || "";
        if (this.lastRenderedCss && renderedCss !== this.lastRenderedCss) this.refinementCount += 1;
        this.lastRenderedCss = renderedCss;
        this.applyCount += 1;
        return {
          status: "rendered_on_live_tab",
          cssBytes: (this.workspace["styles.css"] || "").length,
          autoHealedSurfaces: healStats.healedSurfaces || 0,
          autoHealedTexts: healStats.healedTexts || 0,
          renderIteration: this.applyCount,
          targetedRefinements: this.refinementCount
        };
      }

      case "run_validation": {
        this.onStatus("Tool → run_validation() checking WCAG contrast & affordances...");
        const res = await chrome.tabs.sendMessage(this.tabId, { action: "VALIDATE_AFFORDANCES" });
        const data = res?.data || {
          intact: true,
          score: 100,
          violations: [],
          lowContrastElements: [],
          totalIssues: 0
        };
        this.lastValidation = data;
        this.onStatus(
          `Validation Score: ${data.score}/100 (${data.totalIssues || 0} remaining issues)`
        );
        return data;
      }

      case "take_screenshot": {
        this.onStatus("Tool → take_screenshot() capturing page regions for visual inspection...");
        let plan = { positions: [0], originalY: 0 };
        try {
          await chrome.tabs.sendMessage(this.tabId, { action: "PREPARE_SCREENSHOT" });
          plan = await chrome.tabs.sendMessage(this.tabId, { action: "GET_SCREENSHOT_PLAN" }) || plan;
        } catch {}
        const screenshots = [];
        try {
          for (let i = 0; i < (plan.positions || [0]).length; i++) {
            const y = plan.positions[i];
            await chrome.tabs.sendMessage(this.tabId, { action: "SCROLL_SCREENSHOT_TO", y });
            await new Promise((r) => setTimeout(r, 110));
            const uri = await chrome.tabs.captureVisibleTab(null, { format: "jpeg", quality: 58 });
            if (uri) screenshots.push({ label: `Page segment ${i + 1}/${plan.positions.length} (scroll Y=${y})`, uri });
          }
        } catch (err) {
          this.onStatus(`Screenshot capture warning: ${err.message}`);
        } finally {
          try { await chrome.tabs.sendMessage(this.tabId, { action: "RESTORE_SCREENSHOT_SCROLL", y: plan.originalY || 0 }); } catch {}
          try { await chrome.tabs.sendMessage(this.tabId, { action: "RESTORE_HUD" }); } catch {}
        }
        this.observationCount += screenshots.length ? 1 : 0;
        this.lastScreenshotAttached = screenshots.length > 0;
        return {
          status: screenshots.length ? "captured" : "capture_failed",
          observationNumber: this.observationCount,
          pageHeight: plan.height || null,
          segmentsCaptured: screenshots.length,
          previewImages: screenshots
        };
      }

      case "commit_checkpoint": {
        const id = ++this.currentCheckpointId;
        this.checkpoints.push({
          id,
          description: args.description || `Checkpoint #${id}`,
          workspace: JSON.parse(JSON.stringify(this.workspace))
        });
        this.onStatus(`Tool → commit_checkpoint(#${id}: "${args.description || ""}")`);
        return { status: "checkpoint_saved", checkpointId: id };
      }

      case "undo_change": {
        const target = this.checkpoints.find((c) => c.id === Number(args.checkpointId));
        if (!target) return { error: `Checkpoint ${args.checkpointId} not found` };
        this.workspace = JSON.parse(JSON.stringify(target.workspace));
        await this.executeTool("apply_and_render", {});
        this.onStatus(`Tool → undo_change(reverted to checkpoint #${args.checkpointId})`);
        return { status: "reverted_to", checkpointId: args.checkpointId };
      }

      case "finish_task": {
        if (!this.observationCount) {
          return { error: "Cannot finish yet: capture and inspect a post-render screenshot first." };
        }
        if (!this.lastValidation) {
          return { error: "Cannot finish yet: run live validation after rendering." };
        }
        if (this.refinementCount < 1) {
          return { error: "Cannot finish yet: make at least one evidence-based stylesheet refinement, re-render, and observe it." };
        }
        if (this.todos.length > 0) {
          this.todos = this.todos.map((t) => ({ ...t, status: "completed" }));
          this.onTodos(this.todos);
        }
        this.onStatus("Tool → finish_task() all todos completed!");
        return { status: "complete", summary: args.summary };
      }

      default:
        return { error: `Unknown tool: ${name}` };
    }
  }

  /**
   * Main Autonomous Workspace Loop: Plan Todos -> Inspect -> Write/Edit -> Apply -> Validate/Observe -> Iterate -> Finish
   */
  async run({ userPrompt, initialData, initialScreenshotUri }) {
    this.onStatus("Initializing Autonomous Workspace Agent...");

    this.checkpoints.push({
      id: 0,
      description: "Original Site State",
      workspace: JSON.parse(JSON.stringify(this.workspace))
    });

    // Seed an initial Todo list in the UI immediately while the agent formulates its custom plan
    this.todos = [
      {
        id: 1,
        title: "Plan Todo List & Inspect DOM",
        status: "active",
        desc: "Analyzing semantic graph & creating workspace plan..."
      },
      {
        id: 2,
        title: "Establish Design Tokens (design-spec.json)",
        status: "pending",
        desc: "Locking color palette, typography & surface tokens"
      },
      {
        id: 3,
        title: "Synthesize Full-Page Stylesheet (styles.css)",
        status: "pending",
        desc: "Styling universal [data-rd-role] & semantic containers"
      },
      {
        id: 4,
        title: "Live Render, Screenshot & Sentinel QA",
        status: "pending",
        desc: "Applying styles & running WCAG contrast validation"
      },
      {
        id: 5,
        title: "Iterative Refinement & Finish",
        status: "pending",
        desc: "Polishing any remaining contrast/layout issues"
      }
    ];
    this.onTodos(this.todos);

    this.systemPrompt = `You are an elite Autonomous UI/UX Coding Agent working inside the ReDesigner Workspace Environment.
You work methodically like a senior staff engineer and designer using a Todo list and workspace tools.

YOUR WORKSPACE FILES:
- "todos.json": Managed via manage_todos. Tracks your step-by-step plan and progress.
- "design-spec.json": Stores your design system tokens (palette, typography, spacing, designDirection).
- "styles.css": Your complete CSS stylesheet injected into #redesigner-styles on the live webpage.
- "mutations.json": Optional safe DOM reparenting array.

HOW TO WORK LIKE A GREAT AGENT:
1. PLAN FIRST (manage_todos):
   - In your first turn, call \`manage_todos\` to set up your 4–5 concrete Todo items for this specific page (mark task 1 'completed', task 2 'in_progress'), and optionally call \`inspect_dom\` or \`write_file\` right away!
   - You can call multiple tools in a single turn to work fast and efficiently.
2. WRITE FULL-COVERAGE CSS (write_file -> "styles.css"):
   - Define \`:root\` CSS variables (\`--rd-bg\`, \`--rd-surface\`, \`--rd-surface-elevated\`, \`--rd-text\`, \`--rd-text-muted\`, \`--rd-accent\`, \`--rd-border\`, \`--rd-radius\`, \`--rd-font-sans\`).
   - ALWAYS style universal role attributes so 100% of sections, columns, and lists across the entire page are transformed:
     * \`body, html\`
     * \`[data-rd-role="navbar"]\`
     * \`[data-rd-role="sidebar"]\`
     * \`[data-rd-role="main-content"]\`
     * \`[data-rd-role="section"], [data-rd-role="card-grid"], [data-rd-role="link-list"]\`
     * \`[data-rd-role="section-header"], h1, h2, h3, h4, .ban\`
     * \`[data-rd-role="card-item"], [data-rd-role="list-item"]\`
     * \`a, [data-rd-affordance="navigation-link"]\`
     * \`[data-rd-affordance="action-cta"], button, input, select\`
   - Use \`!important\` on background-color, color, border, and border-radius rules to cleanly override legacy inline/site styles.
3. RENDER & VERIFY (apply_and_render + run_validation):
   - After writing \`styles.css\`, call \`apply_and_render\` and \`run_validation\` (and update \`manage_todos\`).
4. OBSERVE THE RESULT (mandatory):
   - After every apply_and_render, call take_screenshot. The screenshot is attached to your vision context when the selected model supports images. Inspect the actual result rather than assuming injection means success.
   - Then inspect important DOM regions and call run_validation. Judge layout topology, content width, hierarchy, density, alignment, overflow, clipping, responsive behavior and preservation of functionality—not just colors.
   - If the selected model is not vision-capable, use DOM geometry and computed-style probes as your observation source; never claim to have visually inspected an image you could not receive.
6. ITERATE (mandatory):
   - Make at least one meaningful, evidence-based change to styles.css after seeing the first rendered result. Change layout strategy when needed; do not settle for superficial palette/spacing edits.
   - Re-apply, capture another screenshot, and validate again. Use targeted edits and preserve the best checkpoint.
   - Never claim click-through testing unless an actual interaction was exercised.
7. FINISH:
   - Only finish after post-render visual observation, live validation, and at least one changed stylesheet refinement has been rendered. Update todos and summarize exactly what was verified.`;

    const compactGraph = {
      title: initialData.title,
      url: initialData.url,
      viewport: initialData.viewport,
      totalStampedGrids: initialData.totalStampedGrids,
      totalStampedAffordances: initialData.totalStampedAffordances,
      currentDesignState: initialData.currentDesignState,
      universalRoleSelectors: initialData.universalRoleSelectors,
      sampleLandmarks: (initialData.recognizedComponents || []).slice(0, 12),
      sampleAffordances: (initialData.protectedAffordances || []).slice(0, 20)
    };

    const userGoalText = `Redesign Goal: "${
      userPrompt?.trim() ||
      "Perform an autonomous, world-class UI/UX overhaul. Make the page dramatically cleaner, more modern, and intuitive. Maximize visual hierarchy, typography, spacing, and contrast while preserving 100% of functionality."
    }"

Live Page Semantic Overview:
${JSON.stringify(compactGraph, null, 2)}

Start now: create your Todo plan via manage_todos and begin inspecting/writing your design spec and styles.css.`;

    // Initialize Gemini native contents (with initial screenshot if available)
    const initialGeminiParts = [{ text: userGoalText }];
    if (this.isVision && initialScreenshotUri && initialScreenshotUri.includes(",")) {
      initialGeminiParts.push({
        inlineData: {
          mimeType: "image/jpeg",
          data: initialScreenshotUri.split(",")[1]
        }
      });
    }
    this.geminiContents = [{ role: "user", parts: initialGeminiParts }];

    // Initialize OpenAI-compatible history
    this.history = [
      { role: "system", content: this.systemPrompt },
      { role: "user", content: userGoalText }
    ];

    const MAX_TURNS = 16;
    let turn = 0;
    let hasAppliedAtLeastOnce = false;

    while (turn < MAX_TURNS) {
      turn++;
      this.onStatus(`Agent Turn ${turn}/${MAX_TURNS}: Plan → act → observe → refine...`);

      const turnResponse =
        this.provider === "gemini" ? await this.callGeminiTurn() : await this.callOpenAITurn();

      if (turnResponse.thoughtText) {
        const snippet = turnResponse.thoughtText.replace(/\s+/g, " ").trim().slice(0, 140);
        if (snippet) {
          this.onStatus(`Agent: "${snippet}${turnResponse.thoughtText.length > 140 ? "..." : ""}"`);
        }
      }

      const toolCalls = turnResponse.toolCalls || [];

      if (toolCalls.length === 0) {
        // If styles.css is already written, apply and finish
        if ((this.workspace["styles.css"] || "").trim().length > 80) {
          if (!hasAppliedAtLeastOnce) {
            await this.executeTool("apply_and_render", {});
            hasAppliedAtLeastOnce = true;
          }
          const completion = await this.executeTool("finish_task", {
            summary: turnResponse.thoughtText?.slice(0, 120) || "Autonomous workspace redesign complete."
          });
          if (completion?.status === "complete") {
            return {
              success: true,
              summary: completion.summary || turnResponse.thoughtText?.slice(0, 120) || "Autonomous workspace redesign complete.",
              cssRules: this.workspace["styles.css"] || ""
            };
          }
          const nudge = `The completion gate rejected the attempt: ${completion?.error || "missing QA evidence"}. Continue with the required screenshot, validation and targeted refinement.`;
          if (this.provider === "gemini") this.geminiContents.push({ role: "user", parts: [{ text: nudge }] });
          else this.history.push({ role: "user", content: nudge });
          continue;
        }

        // Nudge the model to invoke its tools
        const nudge =
          'Continue working through your Todo list by calling a workspace tool now (e.g., write_file for "styles.css", apply_and_render, run_validation, or finish_task).';
        if (this.provider === "gemini") {
          this.geminiContents.push({ role: "user", parts: [{ text: nudge }] });
        } else {
          this.history.push({ role: "user", content: nudge });
        }
        continue;
      }

      // Execute all tool calls requested in this turn
      const geminiResponseParts = [];
      let finishSummary = null;

      for (const call of toolCalls) {
        const name = call.name;
        const args = call.arguments || {};
        const result = await this.executeTool(name, args);

        if (name === "apply_and_render") {
          hasAppliedAtLeastOnce = true;
        }
        if (name === "finish_task" && result?.status === "complete") {
          finishSummary = args.summary || "Autonomous workspace redesign complete.";
        }

        if (this.provider === "gemini") {
          const cleanResponseObj = { ...result };
          const capturedImg = cleanResponseObj.previewImage;
          const capturedImages = cleanResponseObj.previewImages || [];
          delete cleanResponseObj.previewImage;
          delete cleanResponseObj.previewImages;

          const fnResp = {
            name,
            response: { result: cleanResponseObj }
          };
          if (call.id) {
            fnResp.id = call.id;
          }
          geminiResponseParts.push({ functionResponse: fnResp });

          // If take_screenshot returned a base64 image, attach it as an inlineData part so Gemini sees the screenshot!
          if (capturedImg && capturedImg.includes(",")) {
            geminiResponseParts.push({ inlineData: { mimeType: "image/jpeg", data: capturedImg.split(",")[1] } });
          }
          for (const shot of capturedImages) {
            geminiResponseParts.push({ text: shot.label });
            if (shot.uri?.includes(",")) geminiResponseParts.push({ inlineData: { mimeType: "image/jpeg", data: shot.uri.split(",")[1] } });
          }
        } else {
          const cleanResponseObj = { ...result };
          const capturedImg = cleanResponseObj.previewImage;
          const capturedImages = cleanResponseObj.previewImages || [];
          delete cleanResponseObj.previewImage;
          delete cleanResponseObj.previewImages;
          const serialized = JSON.stringify(cleanResponseObj);

          if (call.isNative) {
            this.history.push({ role: "tool", tool_call_id: call.id, content: serialized });
          } else {
            this.history.push({ role: "user", content: `Tool "${name}" result:\n${serialized}` });
          }
          // Vision-capable OpenAI-compatible models receive the actual rendered screenshot,
          // not just a textual note that a screenshot was captured.
          const visualShots = capturedImages.length ? capturedImages : (capturedImg ? [{ label: "Current viewport", uri: capturedImg }] : []);
          if (visualShots.length && this.isVision) {
            const visualContent = [{ type: "text", text: `Visual observation ${this.observationCount}: inspect these live page segments from top to bottom after the latest changes. Critique the actual layout against the goal and identify concrete corrections.` }];
            for (const shot of visualShots) {
              visualContent.push({ type: "text", text: shot.label });
              visualContent.push({ type: "image_url", image_url: { url: shot.uri, detail: "high" } });
            }
            this.history.push({ role: "user", content: visualContent });
          }
        }
      }

      if (this.provider === "gemini" && geminiResponseParts.length > 0) {
        this.geminiContents.push({
          role: "user",
          parts: geminiResponseParts
        });
      }

      if (finishSummary !== null) {
        if (!hasAppliedAtLeastOnce && (this.workspace["styles.css"] || "").trim().length > 0) {
          await this.executeTool("apply_and_render", {});
        }
        return {
          success: true,
          summary: finishSummary,
          cssRules: this.workspace["styles.css"] || ""
        };
      }
    }

    // Ensure final workspace state is rendered on the live tab
    if ((this.workspace["styles.css"] || "").trim().length > 0) {
      await this.executeTool("apply_and_render", {});
    }
    const completion = await this.executeTool("finish_task", { summary: "Workspace Todo sequence completed." });
    return {
      success: completion?.status === "complete",
      summary: completion?.status === "complete" ? completion.summary : (completion?.error || "Agent reached its turn limit before completing visual QA."),
      cssRules: this.workspace["styles.css"] || ""
    };
  }

  /**
   * Native Gemini v1beta Multi-Turn Function Calling with SSE Streaming (:streamGenerateContent?alt=sse)
   * Preserves model parts & thoughtSignature for Gemini 3.x compatibility and cascades on high traffic.
   */
  async callGeminiTurn() {
    const requestedModel =
      this.model === "gemini-2.5-flash"
        ? "gemini-3.5-flash-lite"
        : this.model || "gemini-3.5-flash-lite";

    const firstTry =
      this.preferredGeminiModel && this.preferredGeminiModel !== requestedModel
        ? [this.preferredGeminiModel, requestedModel]
        : [requestedModel];

    const candidates = Array.from(
      new Set([
        ...firstTry,
        "gemini-3.5-flash-lite",
        "gemini-3.1-flash-lite",
        "gemini-3.6-flash",
        "gemini-omni-1.1-flash",
        "gemini-3-flash-preview",
        "gemini-3.1-pro-preview",
        "gemini-flash-latest"
      ])
    );

    const requestBody = {
      systemInstruction: {
        parts: [{ text: this.systemPrompt }]
      },
      contents: this.geminiContents,
      tools: [
        {
          functionDeclarations: this.getGeminiFunctionDeclarations()
        }
      ],
      toolConfig: {
        functionCallingConfig: {
          mode: "AUTO"
        }
      },
      generationConfig: {
        temperature: 0.5,
        maxOutputTokens: 4096
      }
    };

    let lastError = null;

    for (let i = 0; i < candidates.length; i++) {
      const modelCandidate = candidates[i];
      try {
        const result = await this.executeGeminiStreamOrGenerate(modelCandidate, requestBody);
        this.preferredGeminiModel = modelCandidate;
        return result;
      } catch (err) {
        lastError = err;
        const msg = (err.message || "").toLowerCase();
        if (
          msg.includes("high demand") ||
          msg.includes("overloaded") ||
          msg.includes("unavailable") ||
          msg.includes("resource_exhausted") ||
          msg.includes("quota") ||
          msg.includes("busy") ||
          msg.includes("503") ||
          msg.includes("429") ||
          msg.includes("not found") ||
          msg.includes("not supported") ||
          msg.includes("404")
        ) {
          const nextModel = candidates[i + 1];
          if (nextModel) {
            this.onStatus(`Notice: ${modelCandidate} busy → switching to ${nextModel}...`);
          }
          continue;
        }
        throw err;
      }
    }
    throw lastError;
  }

  async executeGeminiStreamOrGenerate(modelCandidate, requestBody) {
    const streamUrl = `https://generativelanguage.googleapis.com/v1beta/models/${modelCandidate}:streamGenerateContent?alt=sse`;

    const res = await fetch(streamUrl, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-goog-api-key": this.apiKey
      },
      body: JSON.stringify(requestBody)
    });

    if (!res.ok) {
      const errText = await res.text();
      let parsed;
      try {
        parsed = JSON.parse(errText);
      } catch {
        // ignore
      }
      const errMsg = parsed?.error?.message || `HTTP ${res.status}: ${errText.slice(0, 120)}`;
      throw new Error(errMsg);
    }

    // Parse SSE stream chunks and assemble parts (preserving thoughtSignature and functionCall)
    const reader = res.body?.getReader();
    if (!reader) {
      throw new Error("Stream reader unavailable");
    }

    const decoder = new TextDecoder();
    let buffer = "";
    const assembledParts = [];
    let streamedText = "";

    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });

      const lines = buffer.split("\n");
      buffer = lines.pop() || "";

      for (const line of lines) {
        const trimmed = line.trim();
        if (!trimmed.startsWith("data:")) continue;
        const jsonStr = trimmed.slice(5).trim();
        if (!jsonStr || jsonStr === "[DONE]") continue;

        try {
          const chunk = JSON.parse(jsonStr);
          if (chunk.error) {
            throw new Error(chunk.error.message || "Gemini stream error");
          }
          const parts = chunk.candidates?.[0]?.content?.parts || [];
          for (const part of parts) {
            if (typeof part.text === "string" && !part.functionCall) {
              streamedText += part.text;
              // Merge consecutive pure-text parts unless carrying a thoughtSignature
              const prev = assembledParts[assembledParts.length - 1];
              if (
                prev &&
                typeof prev.text === "string" &&
                !prev.functionCall &&
                !prev.thoughtSignature &&
                !part.thoughtSignature
              ) {
                prev.text += part.text;
              } else {
                assembledParts.push(part);
              }
            } else {
              assembledParts.push(part);
            }
          }
        } catch (e) {
          if (e.message && !e.message.includes("JSON")) throw e;
        }
      }
    }

    if (assembledParts.length === 0) {
      throw new Error("Empty response from Gemini stream");
    }

    // Preserve the exact model content (including any Gemini 3 thoughtSignature fields) in conversation history
    this.geminiContents.push({
      role: "model",
      parts: assembledParts
    });

    const toolCalls = [];
    for (const part of assembledParts) {
      if (part.functionCall) {
        toolCalls.push({
          id: part.functionCall.id || null,
          name: part.functionCall.name,
          arguments: part.functionCall.args || {},
          isNative: true
        });
      }
    }

    // Fallback: if model outputted a JSON tool call inside text
    if (toolCalls.length === 0 && streamedText) {
      const fallbackCalls = this.extractFallbackToolCallsFromText(streamedText);
      toolCalls.push(...fallbackCalls);
    }

    return {
      thoughtText: streamedText,
      toolCalls
    };
  }

  /**
   * OpenAI / Groq / OpenRouter Turn Handler
   */
  async callOpenAITurn() {
    const endpoints = {
      nvidia: "https://integrate.api.nvidia.com/v1/chat/completions",
      groq: "https://api.groq.com/openai/v1/chat/completions",
      openrouter: "https://openrouter.ai/api/v1/chat/completions"
    };
    const url = endpoints[this.provider] || endpoints.nvidia;

    const headers = {
      Authorization: `Bearer ${this.apiKey}`,
      "Content-Type": "application/json"
    };

    if (this.provider === "openrouter") {
      headers["HTTP-Referer"] = "https://redesigner.local";
      headers["X-Title"] = "ReDesigner Runtime";
    }

    // Keep the initial instructions plus a contiguous recent tool cycle. Never start
    // a compacted window on an orphaned tool result (providers reject that history).
    let compactHistory = this.history;
    if (this.history.length > 14) {
      let start = this.history.length - 12;
      while (start > 2 && this.history[start]?.role === "tool") start -= 1;
      compactHistory = [this.history[0], this.history[1], ...this.history.slice(start)];
    }

    const payload = {
      model: this.model,
      messages: compactHistory,
      tools: this.getOpenAIToolsSchema(),
      tool_choice: "auto",
      max_tokens: 3072
    };

    let res = await fetch(url, {
      method: "POST",
      headers,
      body: JSON.stringify(payload)
    });

    if (!res.ok) {
      // Fallback for models that do not support native OpenAI tools parameter
      const fallbackMessages = compactHistory.map((m) =>
        m.role === "tool"
          ? { role: "user", content: `Tool result: ${m.content}` }
          : { role: m.role, content: m.content || "" }
      );
      res = await fetch(url, {
        method: "POST",
        headers,
        body: JSON.stringify({
          model: this.model,
          messages: fallbackMessages,
          max_tokens: 3072
        })
      });
    }

    const json = await res.json();
    if (!res.ok || json.error) {
      const msg = json?.error?.message || json?.detail || `HTTP ${res.status}`;
      throw new Error(msg);
    }

    const message = json.choices[0].message;
    this.history.push(message);

    let toolCalls = [];
    if (Array.isArray(message.tool_calls) && message.tool_calls.length > 0) {
      toolCalls = message.tool_calls.map((tc) => {
        let parsedArgs = {};
        try {
          parsedArgs =
            typeof tc.function.arguments === "string"
              ? JSON.parse(tc.function.arguments)
              : tc.function.arguments || {};
        } catch {
          parsedArgs = {};
        }
        return {
          id: tc.id,
          name: tc.function.name,
          arguments: parsedArgs,
          isNative: true
        };
      });
    } else if (typeof message.content === "string" && message.content.trim()) {
      toolCalls = this.extractFallbackToolCallsFromText(message.content);
    }

    return {
      thoughtText: typeof message.content === "string" ? message.content : "",
      toolCalls
    };
  }

  extractFallbackToolCallsFromText(text) {
    if (!text) return [];
    try {
      const cleaned = text
        .replace(/<think>[\s\S]*?<\/think>/gi, "")
        .replace(/```json/gi, "")
        .replace(/```/g, "")
        .trim();
      const first = cleaned.indexOf("{");
      const last = cleaned.lastIndexOf("}");
      if (first !== -1 && last > first) {
        const obj = JSON.parse(cleaned.slice(first, last + 1));
        if (obj.tool && typeof obj.tool === "string") {
          return [
            {
              id: `fallback_${Date.now()}`,
              name: obj.tool,
              arguments: obj.arguments || obj.args || {},
              isNative: false
            }
          ];
        }
        if (obj.cssRules && typeof obj.cssRules === "string") {
          return [
            {
              id: `direct_css_${Date.now()}`,
              name: "write_file",
              arguments: { filename: "styles.css", content: obj.cssRules },
              isNative: false
            },
            {
              id: `direct_apply_${Date.now()}`,
              name: "apply_and_render",
              arguments: {},
              isNative: false
            },
            {
              id: `direct_val_${Date.now()}`,
              name: "run_validation",
              arguments: {},
              isNative: false
            }
          ];
        }
      }
    } catch {
      // ignore
    }
    return [];
  }
}
