// service-worker.js — Adaptive Vision/Text Multi-Provider Agent Orchestrator

import { AgentRuntime } from "./agent-runtime.js";

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "START_AGENT_PIPELINE") {
    executeAgentRuntime(request)
      .then((res) => sendResponse({ success: true, result: res }))
      .catch((err) => {
        emitLog(`Pipeline failed: ${err.message}`, "error");
        sendResponse({ success: false, error: err.message });
      });
    return true;
  }
});

// Pre-inject enforced CSS at browser compositor level during page navigation (status === 'loading')
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === "loading" && tab?.url && tab.url.startsWith("http")) {
    try {
      const host = new URL(tab.url).hostname;
      if (!host) return;
      chrome.storage.local.get(["siteEnforcedDesigns"], (res) => {
        const enforced = res?.siteEnforcedDesigns?.[host];
        if (enforced && enforced.cssRules && enforced.enabled !== false) {
          chrome.scripting
            .insertCSS({
              target: { tabId },
              css: enforced.cssRules
            })
            .catch(() => {});
        }
      });
    } catch {
      // ignore invalid URLs
    }
  }
});

function extractColorSwatches(cssText = "") {
  const bg = cssText.match(/--rd-bg\s*:\s*([^;!}]+)/i)?.[1]?.trim() || "#0b0f17";
  const surface = cssText.match(/--rd-surface\s*:\s*([^;!}]+)/i)?.[1]?.trim() || "#141a26";
  const accent = cssText.match(/--rd-accent\s*:\s*([^;!}]+)/i)?.[1]?.trim() || "#4ade80";
  return [bg, surface, accent];
}

async function saveGeneratedDesignToLibrary({ tabUrl, cssRules, designDirection }) {
  if (!cssRules || cssRules.trim().length < 20) return null;
  let hostname = "universal";
  try {
    hostname = new URL(tabUrl).hostname || "universal";
  } catch {}

  const designEntry = {
    id: `design_${Date.now()}`,
    hostname,
    designDirection: (designDirection || "Autonomous Redesign").slice(0, 65),
    cssRules,
    swatches: extractColorSwatches(cssRules),
    liked: false,
    enabled: true,
    createdAt: Date.now()
  };

  const stored = await chrome.storage.local.get(["savedDesignsLibrary", "siteEnforcedDesigns"]);
  const library = Array.isArray(stored.savedDesignsLibrary) ? stored.savedDesignsLibrary : [];
  const enforcedMap = stored.siteEnforcedDesigns || {};

  // Avoid duplicate identical CSS entries
  const filtered = library.filter((d) => d.cssRules !== cssRules);
  filtered.unshift(designEntry);

  if (hostname && hostname !== "universal") {
    enforcedMap[hostname] = designEntry;
  }

  await chrome.storage.local.set({
    savedDesignsLibrary: filtered.slice(0, 35),
    siteEnforcedDesigns: enforcedMap,
    lastGeneratedCSS: cssRules,
    lastDesignDirection: designEntry.designDirection
  });

  return designEntry;
}

async function ensureContentScript(tabId, tabUrl) {
  if (
    !tabUrl ||
    tabUrl.startsWith("chrome://") ||
    tabUrl.startsWith("chrome-extension://") ||
    tabUrl.startsWith("edge://") ||
    tabUrl.startsWith("about:")
  ) {
    throw new Error("Cannot run on internal browser pages. Please open a regular website.");
  }
  try {
    await chrome.tabs.sendMessage(tabId, { action: "PING" });
  } catch {
    await chrome.scripting.executeScript({ target: { tabId }, files: ["content-script.js"] });
    await new Promise((r) => setTimeout(r, 200));
  }
}

/**
 * Checks whether a model ID is a known multimodal vision-capable model
 */
function isVisionModel(modelId, provider) {
  if (provider === "gemini") return true;
  const name = (modelId || "").toLowerCase();
  return (
    name.includes("vision") ||
    name.includes("vl") ||
    name.includes("flash") ||
    name.includes("4v") ||
    name.includes("4o") ||
    name.includes("pixtral") ||
    name.includes("claude-3") ||
    name.includes("claude-sonnet-4") ||
    name.includes("kimi") ||
    name.includes("gemma-3") ||
    name.includes("llama-4") ||
    name.includes("maverick") ||
    name.includes("scout")
  );
}

async function captureCleanScreenshot(tabId, quality = 60) {
  try {
    await chrome.tabs.sendMessage(tabId, { action: "PREPARE_SCREENSHOT" });
    await new Promise((r) => setTimeout(r, 60));
  } catch {
    // ignore
  }
  let uri = null;
  try {
    uri = await chrome.tabs.captureVisibleTab(null, { format: "jpeg", quality });
  } catch {
    uri = null;
  }
  try {
    await chrome.tabs.sendMessage(tabId, { action: "RESTORE_HUD" });
  } catch {
    // ignore
  }
  return uri;
}

async function executeAgentRuntime({ userPrompt, apiKey, model, provider, agentMode = "react" }) {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.id) throw new Error("No active browser tab found.");

  await chrome.storage.local.set({
    agentRunState: { isRunning: true, startedAt: Date.now(), steps: {}, todos: [] }
  });

  let currentStep = 1;

  try {
    await ensureContentScript(tab.id, tab.url);

    // ==========================================
    // STEP 1: Deep Semantic & Affordance Graph
    // ==========================================
    emitStep(1, "active", "Scanning DOM landmarks & cataloging sacred affordances...");
    emitLog("Analyzing live page semantic layout, hierarchy, and interactive controls...");

    const initialScreenshotUri = await captureCleanScreenshot(tab.id, 60);
    const domResponse = await chrome.tabs.sendMessage(tab.id, { action: "EXTRACT_SEMANTICS" });
    if (!domResponse?.data) throw new Error("Failed to extract DOM semantics from page.");
    const siteGraph = domResponse.data;

    emitLog(
      `Cataloged ${siteGraph.recognizedComponents.length} landmarks (${siteGraph.totalStampedGrids || 0} total grids/lists stamped across page).`
    );
    emitLog(`Protected ${siteGraph.totalStampedAffordances || siteGraph.protectedAffordances.length} interactive controls.`);
    emitStep(
      1,
      "completed",
      `Stamped ${siteGraph.totalStampedGrids || siteGraph.recognizedComponents.length} grids/sections, ${siteGraph.totalStampedAffordances || siteGraph.protectedAffordances.length} controls.`
    );

    const visionEnabled = isVisionModel(model, provider) && Boolean(initialScreenshotUri);

    // ==========================================
    // MODE A (DEFAULT): Autonomous Workspace Agent (Todo + Tools Loop)
    // ==========================================
    if (agentMode === "react") {
      currentStep = 2;
      emitLog(`Launching Workspace Coding Agent (${model}) with Todo & DOM tools...`, "system");
      const runtime = new AgentRuntime({
        tabId: tab.id,
        provider,
        model,
        apiKey,
        isVision: visionEnabled,
        onStatus: (text) => emitLog(text, "action"),
        onStep: (step, status, desc) => {
          currentStep = step;
          emitStep(step, status, desc);
        },
        onTodos: (todos) => emitTodos(todos)
      });

      const reactResult = await runtime.run({
        userPrompt,
        initialData: siteGraph,
        initialScreenshotUri
      });
      const savedEntry = await saveGeneratedDesignToLibrary({
        tabUrl: tab.url,
        cssRules: reactResult.cssRules || "",
        designDirection: reactResult.summary || "Autonomous Workspace Overhaul"
      });
      emitLog(`✓ ${reactResult.summary}`, "success");
      emitLog("📌 Design saved to gallery & enforced on this site!", "system");
      return {
        success: true,
        designId: savedEntry?.id,
        cssRules: reactResult.cssRules || "",
        designDirection: reactResult.summary
      };
    }

    // ==========================================
    // STEP 2: Senior UI/UX Architect Agent
    // ==========================================
    currentStep = 2;
    emitStep(2, "active", `Senior Designer formulating layout (${model})...`);
    emitLog(
      `Dispatching to ${provider.toUpperCase()} (${
        visionEnabled ? "Multimodal Vision Mode" : "Semantic Layout Mode"
      })...`
    );

    const effectiveGoal =
      userPrompt?.trim() ||
      "Perform an autonomous, world-class UI/UX overhaul. Make the page dramatically cleaner, more modern, and intuitive. Maximize visual hierarchy, typography, spacing, and contrast while preserving 100% of functionality.";

    const designPlan = await callModelDispatcher({
      provider,
      apiKey,
      model,
      role: "designer",
      userPrompt: effectiveGoal,
      screenshotUri: initialScreenshotUri,
      siteGraph,
      isVision: visionEnabled
    });

    const cssRules = designPlan.cssRules || "";
    const designDirection = designPlan.designDirection || "Modernized UI System";

    emitLog(`Design direction: "${designDirection}"`);
    emitLog(`Synthesized ${cssRules.length} bytes of scoped CSS.`);
    emitStep(2, "completed", `Synthesized ${cssRules.length}B CSS (${designDirection.slice(0, 36)})`);

    // ==========================================
    // STEP 3: Live DOM & Style Injection
    // ==========================================
    currentStep = 3;
    emitStep(3, "active", "Injecting scoped stylesheet & rendering...");
    emitLog("Injecting #redesigner-styles into live document...");

    const applyRes = await chrome.tabs.sendMessage(tab.id, {
      action: "APPLY_REDESIGN",
      patch: {
        designDirection,
        cssRules,
        domMutations: Array.isArray(designPlan.domMutations) ? designPlan.domMutations : []
      }
    });
    await new Promise((r) => setTimeout(r, 450));

    if (applyRes?.healStats) {
      const { healedSurfaces, healedTexts } = applyRes.healStats;
      if (healedSurfaces > 0 || healedTexts > 0) {
        emitLog(
          `Auto-Healer normalized ${healedSurfaces} legacy background boxes & ${healedTexts} low-contrast text/link nodes.`
        );
      }
    }

    const valResponse = await chrome.tabs.sendMessage(tab.id, { action: "VALIDATE_AFFORDANCES" });
    const validationReport = valResponse?.data || {
      intact: true,
      score: 100,
      violations: [],
      lowContrastElements: [],
      totalIssues: 0
    };

    emitLog(
      `Live tab updated! Sentinel QA Score: ${validationReport.score}/100 (${validationReport.totalIssues} contrast/affordance flags).`
    );
    emitStep(3, "completed", `Rendered (${validationReport.score}/100 Sentinel integrity).`);

    // ==========================================
    // STEP 4: Visual & Sentinel QA Critic Pass
    // ==========================================
    currentStep = 4;
    let finalCSS = cssRules;

    if (true) {
      emitStep(
        4,
        "active",
        visionEnabled
          ? "Visual + functional Critic inspecting the rendered page..."
          : `Structural Critic reviewing layout and ${validationReport.totalIssues} Sentinel findings...`
      );

      const postScreenshotUri = visionEnabled ? await captureCleanScreenshot(tab.id, 60) : null;

      try {
        const criticPatch = await callModelDispatcher({
          provider,
          apiKey,
          model,
          role: "critic",
          userPrompt: effectiveGoal,
          screenshotUri: postScreenshotUri,
          designPlan,
          siteGraph,
          validationReport,
          isVision: visionEnabled && Boolean(postScreenshotUri)
        });

        const refinement = (criticPatch?.refinementCSS || criticPatch?.cssRules || "").trim();
        if (refinement.length > 10) {
          finalCSS = `${cssRules}\n\n/* === QA Critic Refinement Pass === */\n${refinement}`;
          emitLog(
            `Critic synthesized ${refinement.length}B polish patch: "${
              criticPatch.criticAssessment?.slice(0, 70) || "Contrast & layout tuned"
            }"`
          );
          await chrome.tabs.sendMessage(tab.id, {
            action: "APPLY_REDESIGN",
            patch: {
              designDirection,
              cssRules: finalCSS,
              domMutations: []
            }
          });
        }
        emitStep(4, "completed", "Visual contrast & affordances verified.");
      } catch (e) {
        emitLog(`Critic pass skipped (${e.message}). Initial redesign preserved.`, "cooldown");
        emitStep(4, "completed", "Passed (Initial redesign preserved).");
      }
    } else {
      emitStep(4, "completed", "Verified (100/100 Sentinel score).");
    }

    const savedEntry = await saveGeneratedDesignToLibrary({
      tabUrl: tab.url,
      cssRules: finalCSS,
      designDirection
    });

    emitLog("✓ Redesign pipeline completed & pinned to site!", "success");
    return {
      success: true,
      designId: savedEntry?.id,
      cssRules: finalCSS,
      designDirection
    };
  } catch (err) {
    emitStep(currentStep, "error", err.message.slice(0, 75));
    throw err;
  } finally {
    const stored = await chrome.storage.local.get(["agentRunState"]);
    const state = stored.agentRunState || {};
    state.isRunning = false;
    await chrome.storage.local.set({ agentRunState: state });
  }
}

function emitStep(step, status, desc) {
  chrome.runtime.sendMessage({ action: "AGENT_STEP_UPDATE", step, status, desc }, () => {
    if (chrome.runtime.lastError) {
      /* Popup may be closed; state is also persisted in storage */
    }
  });
}

function emitTodos(todos) {
  chrome.storage.local.get(["agentRunState"], (res) => {
    const state = res.agentRunState || { isRunning: true, steps: {} };
    state.todos = todos;
    chrome.storage.local.set({ agentRunState: state });
  });
  chrome.runtime.sendMessage({ action: "AGENT_TODOS_UPDATE", todos }, () => {
    if (chrome.runtime.lastError) {
      /* Popup may be closed */
    }
  });
}

function emitLog(text, logType = "action") {
  chrome.runtime.sendMessage({ action: "AGENT_LOG", text, logType }, () => {
    if (chrome.runtime.lastError) {
      /* Popup may be closed */
    }
  });
}

function buildPrompts(args) {
  const isDesigner = args.role === "designer";

  if (isDesigner) {
    const systemInstructions = `You are an elite Principal UI/UX Architect and Design Systems Engineer.
Your mission is to transform the live webpage according to: "${args.userPrompt}".

CORE ARCHITECTURAL MANDATES:
0. CARTOGRAPHY FIRST: Read accessibilityMap, visualMap and pageMetrics before proposing a layout. Infer information hierarchy from headings, accessible names, landmarks and repeated structures. Screenshot is visual evidence; semantic map is structural source of truth.
0.1 BLUEPRINT BEFORE CSS: Define information architecture, primary/secondary regions, responsive layout topology, component treatments, preserved interactions and risks. Return these in a concise uxBlueprint object.
0.2 PAGE-SPECIFIC DESIGN: Preserve site identity and content purpose. Do not default every website to the same dashboard/streaming aesthetic. Avoid turning every section/header into a card.
0.3 SAFE TRANSFORMATION: CSS-first and non-destructive. Do not remove, clone, reorder, replace, hide, disable or rewrite functional DOM nodes. Do not invent replacement controls. Browser APIs cannot enumerate all existing event handlers; preserve them by keeping original nodes in place.
1. DESIGN SYSTEM TOKENS: Start your CSS with a :root block defining cohesive tokens (--rd-bg, --rd-surface, --rd-surface-elevated, --rd-text, --rd-text-muted, --rd-accent, --rd-border, --rd-radius, --rd-font-sans).
2. THEME ADAPTATION:
   - Unless the user asks for a light/editorial theme, craft a refined obsidian/slate dark UI (#0b0f17 background, #141a26 elevated cards, 1px solid rgba(255,255,255,0.08) borders, 12px border-radius, subtle shadows).
   - If the user asks for "Editorial", "Light", or a specific palette, honor that palette faithfully with crisp contrast.
3. GUARANTEED READABILITY & CONTRAST:
   - Never leave dark text on dark backgrounds or light text on light backgrounds!
   - Explicitly style headings (h1, h2, h3, [data-rd-role^="heading-"]), paragraphs, links, list items, and table cells inside redesigned containers with high-contrast colors using !important where needed to override legacy inline/site styles.
4. UNIVERSAL ROLE SELECTOR STRATEGY (CRITICAL FOR FULL-PAGE COVERAGE):
   - Always style universal role selectors FIRST so 100% of sections/lists on the page get styled, not just 2 or 3 specific IDs!
   - Style:
     * body, html (background: var(--rd-bg) !important; color: var(--rd-text) !important; font-family: var(--rd-font-sans) !important;)
     * [data-rd-role="navbar"] (sleek top bar, sticky/backdrop-filter, clean padding & border-bottom)
     * [data-rd-role="sidebar"] (clean card panel with var(--rd-surface), rounded corners, subtle border, comfortable padding)
     * [data-rd-role="main-content"] (modern container spacing and clean layout)
     * [data-rd-role="section"], [data-rd-role="card-grid"], [data-rd-role="link-list"] (modern card surfaces: background: var(--rd-surface) !important; border: 1px solid var(--rd-border) !important; border-radius: var(--rd-radius) !important; padding: 14px !important;)
     * [data-rd-role="section-header"], h1, h2, h3, h4, .ban (background: var(--rd-surface-elevated) !important; color: var(--rd-text) !important; font-weight: 700 !important; border-radius: 8px !important; padding: 8px 12px !important; border: none !important;)
     * [data-rd-role="card-item"], [data-rd-role="list-item"] (clean spacing, subtle hover states)
     * a, [data-rd-affordance="navigation-link"] (high-contrast readable link color var(--rd-accent) or var(--rd-text) !important; text-decoration: none !important;)
     * [data-rd-affordance="action-cta"], button, [type="submit"] (modern button styling)
     * [data-rd-affordance="search-input"], [data-rd-affordance="form-control"], input, select (modern dark/light input surface with crisp border and readable text)
   - Only use specific [data-rd-id="..."] selectors when applying custom grid columns or targeted overrides to a specific container.
5. SACRED AFFORDANCES:
   - Preserve 100% of interactive controls (search inputs, buttons, navigation links, forms). Style [data-rd-affordance="action-cta"] and [data-rd-affordance="search-input"] to look modern, accessible, and unmistakable.
6. LAYOUT & SPACING:
   - Give [data-rd-role="card-grid"] responsive CSS grid layouts (e.g. display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 20px;) when appropriate.
   - Remove cluttered legacy borders and raw <hr> dividers.

Return ONLY a valid JSON object matching this exact structure (no markdown commentary outside JSON):
{
  "designDirection": "Concise 4-8 word summary of the visual direction",
  "uxBlueprint": {
    "pagePurpose": "What this page is for",
    "hierarchy": ["Primary content", "Secondary content"],
    "layoutTopology": "Responsive composition",
    "componentRules": ["Specific treatment decisions"],
    "preservedInteractions": ["Existing controls and behaviors"],
    "risks": ["Potential regressions"]
  },
  "cssRules": "/* Complete, page-specific CSS stylesheet */",
  "domMutations": []
}`;

    const userText = `Redesign Goal: ${args.userPrompt}

Page Context:
- Title: ${args.siteGraph.title}
- URL: ${args.siteGraph.url || ""}
- Current State: ${JSON.stringify(args.siteGraph.currentDesignState)}
- Recognized Landmarks & Grids (${args.siteGraph.recognizedComponents.length}):
${JSON.stringify(args.siteGraph.recognizedComponents.slice(0, 14), null, 2)}
- Protected Interactive Affordances (${args.siteGraph.protectedAffordances.length}):
${JSON.stringify(args.siteGraph.protectedAffordances.slice(0, 45), null, 2)}
- Accessibility/AX-style Map:
${JSON.stringify(args.siteGraph.accessibilityMap || [], null, 2)}
- Visual Landmark Map:
${JSON.stringify(args.siteGraph.visualMap || [], null, 2)}
- Page Metrics:
${JSON.stringify(args.siteGraph.pageMetrics || {}, null, 2)}
- Preservation Contract:
${JSON.stringify(args.siteGraph.preservationContract || {}, null, 2)}

Produce a coherent page-specific redesign. Use existing data-rd-id selectors only for justified layout mapping. Keep DOM mutations empty unless essential.`;

    return { systemInstructions, userText };
  }

  // Critic role
  const systemInstructions = `You are a Principal Visual QA & Accessibility Critic.
Inspect the redesigned page state and Sentinel validation report for the goal: "${args.userPrompt}".

Act as an independent release gate. Compare the rendered page against the original semantic/visual map and UX blueprint. Return a small targeted patch only when evidence supports it. Never change or hide functional controls.

Check for:
1. Any low-contrast text (e.g., unreadable links, muted text, or unstyled child elements inside cards/tables/headers).
2. Any collapsed or hidden interactive affordances reported by the Sentinel.
3. Visual alignment, padding, overflow, or navbar/sidebar spacing glitches.

Return ONLY a valid JSON object matching this exact structure:
{
  "criticAssessment": "Brief summary of what looks good and what was fixed",
  "refinementCSS": "/* Supplemental corrective CSS rules using high-specificity selectors and !important where needed */"
}`;

  const userText = `Applied Design Direction: "${args.designPlan?.designDirection || "Modern UI"}"
Automated Sentinel Report (Score ${args.validationReport?.score ?? 100}/100):
- Collapsed/Hidden Affordances: ${JSON.stringify(args.validationReport?.violations || [])}
- Low Contrast Elements: ${JSON.stringify(args.validationReport?.lowContrastElements || [])}
- Original Page Landmarks: ${JSON.stringify(args.siteGraph?.visualMap || [])}
- Original Interactive Controls: ${JSON.stringify(args.siteGraph?.protectedAffordances || [])}
- Blueprint: ${JSON.stringify(args.designPlan?.uxBlueprint || {})}

Existing CSS Snippet:
${(args.designPlan?.cssRules || "").slice(0, 2500)}`;

  return { systemInstructions, userText };
}

async function callModelDispatcher(args) {
  if (args.provider === "nvidia") {
    return callOpenAICompatible({
      providerName: "NVIDIA NIM",
      url: "https://integrate.api.nvidia.com/v1/chat/completions",
      headers: {
        Authorization: `Bearer ${args.apiKey}`,
        Accept: "application/json"
      },
      ...args
    });
  } else if (args.provider === "groq") {
    return callOpenAICompatible({
      providerName: "Groq",
      url: "https://api.groq.com/openai/v1/chat/completions",
      headers: { Authorization: `Bearer ${args.apiKey}` },
      ...args
    });
  } else if (args.provider === "openrouter") {
    return callOpenAICompatible({
      providerName: "OpenRouter",
      url: "https://openrouter.ai/api/v1/chat/completions",
      headers: {
        Authorization: `Bearer ${args.apiKey}`,
        "HTTP-Referer": "https://redesigner.local",
        "X-Title": "ReDesigner Agent"
      },
      ...args
    });
  } else {
    return callGeminiWithFallback(args);
  }
}

/**
 * Unified OpenAI-Compatible Engine (NVIDIA NIM, Groq, OpenRouter)
 * Automatically retries in pure-text mode if a model rejects multimodal image input.
 */
async function callOpenAICompatible(args) {
  const { systemInstructions, userText } = buildPrompts(args);

  const sendRequest = async (useVision) => {
    const userMessageContent =
      useVision && args.screenshotUri
        ? [
            { type: "text", text: `${systemInstructions}\n\n${userText}` },
            { type: "image_url", image_url: { url: args.screenshotUri } }
          ]
        : `${systemInstructions}\n\n${userText}`;

    const payload = {
      model: args.model,
      messages: [{ role: "user", content: userMessageContent }],
      temperature: 0.65,
      top_p: 0.95,
      max_tokens: 4096
    };

    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 65000);

    try {
      const res = await fetch(args.url, {
        method: "POST",
        headers: {
          ...args.headers,
          "Content-Type": "application/json"
        },
        body: JSON.stringify(payload),
        signal: controller.signal
      });

      clearTimeout(timeoutId);

      if (!res.ok) {
        const errorText = await res.text();
        let parsed;
        try {
          parsed = JSON.parse(errorText);
        } catch {
          // ignore
        }
        const errMsg =
          parsed?.detail ||
          parsed?.title ||
          parsed?.error?.message ||
          parsed?.message ||
          `HTTP ${res.status}: ${errorText.slice(0, 160)}`;
        const error = new Error(`${args.providerName}: ${errMsg}`);
        error.status = res.status;
        error.raw = errorText;
        throw error;
      }

      const json = await res.json();
      const rawContent = json.choices?.[0]?.message?.content;
      if (!rawContent) throw new Error(`Empty response received from ${args.providerName}.`);

      return cleanAndParseJSON(rawContent);
    } catch (err) {
      clearTimeout(timeoutId);
      if (err.name === "AbortError") {
        throw new Error(
          `Model ${args.model} timed out after 65s. Try a faster model or switch provider.`
        );
      }
      throw err;
    }
  };

  try {
    return await sendRequest(args.isVision);
  } catch (err) {
    // If vision payload was rejected OR hit a 413/429 TPM rate limit (common on Groq), retry in compact text mode
    const msg = (err.message || "").toLowerCase();
    if (
      args.isVision &&
      (msg.includes("image") ||
        msg.includes("multimodal") ||
        msg.includes("vision") ||
        msg.includes("content must be a string") ||
        msg.includes("rate_limit") ||
        msg.includes("tokens") ||
        msg.includes("too large") ||
        err.status === 400 ||
        err.status === 413 ||
        err.status === 422 ||
        err.status === 429)
    ) {
      emitLog(
        `Retrying ${args.providerName} in lightweight Semantic Text Mode to bypass vision/token limit...`,
        "cooldown"
      );
      return await sendRequest(false);
    }
    throw err;
  }
}

let preferredGeminiModel = null;

async function callGeminiWithFallback(args) {
  // Automatically migrate deprecated gemini-2.5-flash to gemini-3.5-flash-lite
  const requestedModel =
    args.model === "gemini-2.5-flash" ? "gemini-3.5-flash-lite" : args.model || "gemini-3.5-flash-lite";

  const firstTry =
    preferredGeminiModel && preferredGeminiModel !== requestedModel
      ? [preferredGeminiModel, requestedModel]
      : [requestedModel];

  const candidates = Array.from(
    new Set([
      ...firstTry,
      "gemini-3.5-flash-lite",
      "gemini-3.1-flash-lite",
      "gemini-3.6-flash",
      "gemini-omni-1.1-flash",
      "gemini-3-flash-preview",
      "gemini-3.1-pro-preview",
      "gemini-flash-latest"
    ])
  );
  let lastError = null;

  for (let i = 0; i < candidates.length; i++) {
    const modelCandidate = candidates[i];
    try {
      const result = await executeGeminiRequest({ ...args, model: modelCandidate });
      preferredGeminiModel = modelCandidate;
      return result;
    } catch (err) {
      lastError = err;
      const msg = (err.message || "").toLowerCase();
      if (
        msg.includes("high demand") ||
        msg.includes("overloaded") ||
        msg.includes("unavailable") ||
        msg.includes("resource_exhausted") ||
        msg.includes("quota") ||
        msg.includes("busy") ||
        msg.includes("503") ||
        msg.includes("429") ||
        msg.includes("not found") ||
        msg.includes("not supported") ||
        msg.includes("404")
      ) {
        const nextModel = candidates[i + 1];
        if (nextModel) {
          emitLog(`Notice: ${modelCandidate} busy → switching to ${nextModel}...`, "cooldown");
        }
        continue;
      }
      throw err;
    }
  }
  throw lastError;
}

async function executeGeminiRequest(args) {
  const { apiKey, model, screenshotUri, role } = args;
  const endpoint = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`;
  const { systemInstructions, userText } = buildPrompts(args);

  const isDesigner = role === "designer";
  const schema = isDesigner
    ? {
        type: "OBJECT",
        properties: {
          designDirection: { type: "STRING" },
          cssRules: { type: "STRING" },
          domMutations: {
            type: "ARRAY",
            items: {
              type: "OBJECT",
              properties: {
                action: { type: "STRING", enum: ["reparent"] },
                sourceId: { type: "STRING" },
                targetId: { type: "STRING" },
                position: { type: "STRING", enum: ["append", "prepend"] }
              },
              required: ["action", "sourceId", "targetId", "position"]
            }
          }
        },
        required: ["designDirection", "cssRules", "domMutations"]
      }
    : {
        type: "OBJECT",
        properties: {
          criticAssessment: { type: "STRING" },
          refinementCSS: { type: "STRING" }
        },
        required: ["criticAssessment", "refinementCSS"]
      };

  const parts = [{ text: `${systemInstructions}\n\n${userText}` }];
  if (screenshotUri && screenshotUri.includes(",")) {
    parts.push({
      inlineData: {
        mimeType: "image/jpeg",
        data: screenshotUri.split(",")[1]
      }
    });
  }

  const res = await fetch(endpoint, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-goog-api-key": apiKey
    },
    body: JSON.stringify({
      contents: [{ role: "user", parts }],
      generationConfig: {
        responseMimeType: "application/json",
        responseSchema: schema,
        maxOutputTokens: 4096
      }
    })
  });

  const json = await res.json();
  if (!res.ok || json.error) {
    // Fallback to Interactions API if the chosen model requires /v1beta/interactions
    const errMsg = json?.error?.message || `HTTP ${res.status}`;
    if (res.status === 404 || errMsg.toLowerCase().includes("interactions")) {
      return await executeGeminiInteractionsFallback({
        apiKey,
        model,
        prompt: `${systemInstructions}\n\n${userText}`
      });
    }
    throw new Error(`${errMsg} (${res.status})`);
  }
  const rawText = json.candidates?.[0]?.content?.parts?.[0]?.text;
  return cleanAndParseJSON(rawText);
}

async function executeGeminiInteractionsFallback({ apiKey, model, prompt }) {
  const res = await fetch("https://generativelanguage.googleapis.com/v1beta/interactions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-goog-api-key": apiKey
    },
    body: JSON.stringify({
      model,
      input: prompt
    })
  });

  const json = await res.json();
  if (!res.ok || json.error) {
    throw new Error(json?.error?.message || `Interactions API HTTP ${res.status}`);
  }
  const rawText =
    json.output_text ||
    json.outputs?.[0]?.text ||
    json.candidates?.[0]?.content?.parts?.[0]?.text;
  return cleanAndParseJSON(rawText);
}

function cleanAndParseJSON(raw) {
  if (!raw) throw new Error("Empty response from AI model.");

  let cleaned = raw.replace(/<think>[\s\S]*?<\/think>/gi, "");
  cleaned = cleaned.replace(/```json/gi, "").replace(/```/g, "").trim();

  const firstBrace = cleaned.indexOf("{");
  const lastBrace = cleaned.lastIndexOf("}");
  if (firstBrace !== -1 && lastBrace !== -1 && lastBrace > firstBrace) {
    const candidate = cleaned.substring(firstBrace, lastBrace + 1);
    try {
      return JSON.parse(candidate);
    } catch {
      // Remove trailing commas before closing braces/brackets and retry
      const repaired = candidate.replace(/,\s*([}\]])/g, "$1");
      try {
        return JSON.parse(repaired);
      } catch {
        // Fallback: extract cssRules manually if unescaped newlines broke JSON string
        const cssMatch = candidate.match(/"cssRules"\s*:\s*"([\s\S]*?)"\s*(?:,\s*"domMutations"|\})/);
        if (cssMatch) {
          return {
            designDirection: "Autonomous UI Overhaul",
            cssRules: cssMatch[1].replace(/\\n/g, "\n").replace(/\\"/g, '"'),
            domMutations: []
          };
        }
      }
    }
  }

  // Last resort: if model returned raw CSS block directly
  if (cleaned.includes("{") && (cleaned.includes(":root") || cleaned.includes("body"))) {
    return {
      designDirection: "Direct CSS Synthesis",
      cssRules: cleaned,
      domMutations: []
    };
  }

  return JSON.parse(cleaned);
}
