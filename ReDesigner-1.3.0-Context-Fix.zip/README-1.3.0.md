# ReDesigner 1.3.0 — Context Budget Fix

## What changed
- Compacts the scanned page into a small site map before sending it to Groq.
- Scores components against the user's instruction and prioritizes likely targets.
- Caps candidate/component counts and total context size.
- Removes long CSS/JS resource URLs and repeated per-element details from the model prompt; keeps resource counts.
- Limits completion output and retries once with a smaller map when Groq reports a token/TPM-size problem.
- Reports offline fallback honestly: it no longer presents a local theme as an AI redesign.

## Why this matters
The previous build sent up to 36 candidates and 45 component descriptions, which produced a request of 13,111 tokens. The new default request has a 10,000-character hard ceiling on the compact site map, 12 candidates, 10 components and a 900-token completion ceiling. A second attempt reduces these limits further. Token estimates are logged in the service worker console; provider accounting can vary.

## Install
1. Extract this ZIP.
2. Open `chrome://extensions`.
3. Remove/disable the older ReDesigner build or use **Reload** after replacing its folder.
4. Click **Load unpacked** and select the folder containing `manifest.json`.
5. Open a website, open ReDesigner and enter a specific redesign request.

## Notes
The scanner still runs in the page, but the AI receives only the relevant compact summary. This build does not yet implement the full multi-turn inspect-component tool loop or screenshot-based visual evaluation; those are the next agent milestones. Groq can still reject a request if the organization has already consumed its TPM allowance during the current minute.
