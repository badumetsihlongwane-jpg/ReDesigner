# ReDesigner 1.2.0 — Environment preview

## What's changed
- The floating ReDesigner control is collapsed by default. Click the small RD pill to open the panel; click × to collapse it again.
- Page load no longer automatically applies a generic redesign. The extension inspects the page and waits for an explicit redesign request.
- The environment scanner builds a compact route-specific map of up to 70 visible components, including selectors, geometry, computed layout styles, small text samples, links, viewport dimensions, stylesheet references, script references, and image counts.
- The worker includes this map in the model request, so the model can target changes with more context than the previous lightweight anatomy scan.
- Generic automatic grid styling and semantic-zone rearrangement are disabled to reduce damage to sites whose layouts depend on their own component system.
- Saved design profiles are now keyed by origin + pathname instead of origin alone.

## Install / update
1. Extract this ZIP to a folder.
2. Open `chrome://extensions` in Chrome.
3. Enable Developer mode.
4. If the previous ReDesigner build is installed, click Reload after selecting the unpacked folder, or remove the old one first to avoid duplicate extensions.
5. Click **Load unpacked** and select the extracted folder containing `manifest.json`.
6. Open a website and click the collapsed **RD / ReDesigner** pill in the lower-right corner.
7. Enter a specific goal, then click **Apply**. Configure your Groq API key in the extension popup if you want AI-directed changes.

## Important limitations
This is an incremental environment-engine prototype, not yet a full autonomous visual agent. It does not download or parse arbitrary source-code files, execute a screenshot-based critique loop, or safely edit a site's original JavaScript. Cross-origin stylesheet rules may be inaccessible; their URLs and access status are recorded instead. The browser extension still applies reversible inline/CSS changes, not source-file edits. Test on non-critical pages first.
