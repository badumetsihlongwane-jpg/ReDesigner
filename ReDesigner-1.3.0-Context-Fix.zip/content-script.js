"use strict";
(() => {
  // src/shared/blueprint.ts
  var variations = {
    vision: { accent: "#55d6be", background: "#0b1115", surface: "#142027" },
    editorial: { accent: "#d96c4b", background: "#f5f0e8", surface: "#fffaf3" },
    executive: { accent: "#e8b44c", background: "#151718", surface: "#222729" }
  };
  function fallbackBlueprint(archetype, variation = "vision") {
    const order = archetype === "shopping" ? ["header", "search", "secondary", "main", "actions", "footer"] : ["header", "search", "actions", "main", "secondary", "footer"];
    const hiddenRoles = [];
    return { version: 1, archetype, variation, zoneOrder: order, hiddenRoles, density: archetype === "government" ? "airy" : "comfortable", ...variations[variation], rationale: "Local semantic layout selected for reliable offline use.", operations: [] };
  }

  // src/shared/anatomy.ts
  var roleWords = {
    header: /header|nav|navbar|masthead|topbar|brand/i,
    search: /search|query|filter/i,
    secondary: /sidebar|aside|drawer|menu|category|filter/i,
    actions: /action[-_ ]?bar|toolbar|account[-_ ]?menu|cart[-_ ]?summary|checkout[-_ ]?panel/i,
    footer: /footer|legal|copyright/i,
    clutter: /advert|sponsor|promo|cookie|consent|newsletter|banner/i
  };
  function selectorFor(element) {
    if (element.id) return `#${CSS.escape(element.id)}`;
    const parts = [];
    let current = element;
    while (current && current.nodeType === 1 && current !== document.documentElement && parts.length < 6) {
      let part = current.tagName.toLowerCase();
      const parent = current.parentElement;
      if (parent) {
        const sameTag = [...parent.children].filter((child) => child.tagName === current.tagName);
        if (sameTag.length > 1) part += `:nth-of-type(${sameTag.indexOf(current) + 1})`;
      }
      parts.unshift(part);
      const candidate = parts.join(" > ");
      try {
        if (document.querySelectorAll(candidate).length === 1) return candidate;
      } catch { /* continue building a more specific path */ }
      current = parent;
    }
    return parts.join(" > ") || element.tagName.toLowerCase();
  }
  function textOf(element) {
    return (element.textContent || "").replace(/\s+/g, " ").trim().slice(0, 140);
  }
  function classify(element) {
    const signature = `${element.tagName} ${element.id} ${element.className} ${element.getAttribute("aria-label") || ""}`;
    for (const [role, pattern] of Object.entries(roleWords)) {
      if (pattern.test(signature)) return role;
    }
    return null;
  }
  function inferArchetype() {
    const text = `${document.title} ${document.body.innerText.slice(0, 5e3)}`.toLowerCase();
    if (/cart|add to cart|buy now|price|shop|product/.test(text)) return "shopping";
    if (/course|assignment|semester|canvas|blackboard|student portal/.test(text)) return "education";
    if (/government|permit|tax|dmv|public service|official form/.test(text)) return "government";
    if (/breaking news|subscribe|author|opinion|latest news/.test(text)) return "news";
    if (/timeline|feed|follow|repost|community/.test(text)) return "social";
    if (/watch now|episodes|season|trailer|play video/.test(text)) return "streaming";
    if (/analytics|dashboard|workspace|reports|metrics/.test(text)) return "dashboard";
    return "general";
  }
  function scanAnatomy() {
    const candidates = [...document.querySelectorAll("header, nav, main, aside, footer, section, form, [role], [class], [id]")];
    const zones = /* @__PURE__ */ new Map();
    const layoutCandidates = [];
    for (const element of candidates) {
      if (element.closest("[data-redesigner-hud]")) continue;
      const role = element.tagName.toLowerCase() === "main" ? "main" : classify(element);
      const rect = element.getBoundingClientRect();
      const zone = {
        role: role || "main",
        selector: selectorFor(element),
        tag: element.tagName.toLowerCase(),
        text: textOf(element),
        rect: { width: Math.round(rect.width), height: Math.round(rect.height) },
        count: element.children.length
      };
      if (role && !zones.has(role)) zones.set(role, zone);
      if (element.children.length >= 3 && rect.width >= 240 && rect.height >= 80) layoutCandidates.push(zone);
    }
    if (!zones.has("main")) {
      const main = document.querySelector('body > div, article, [role="main"]');
      if (main) zones.set("main", { role: "main", selector: selectorFor(main), tag: main.tagName.toLowerCase(), text: textOf(main), rect: { width: Math.round(main.getBoundingClientRect().width), height: Math.round(main.getBoundingClientRect().height) }, count: main.children.length });
    }
    return {
      url: location.href,
      origin: location.origin,
      title: document.title,
      archetypeHint: inferArchetype(),
      zones: [...zones.values()].slice(0, 8),
      candidates: layoutCandidates.slice(0, 36),
      interactiveCounts: {
        links: document.links.length,
        buttons: document.querySelectorAll('button, [role="button"]').length,
        forms: document.forms.length,
        inputs: document.querySelectorAll("input, select, textarea").length,
        media: document.querySelectorAll("video, audio, iframe, img").length
      }
    };
  }

  // Compact environment model: hierarchy, computed layout, assets and interaction clues.
  function scanEnvironment() {
    const anatomy = scanAnatomy(); const components = []; const seen = new Set();
    const nodes = [...document.querySelectorAll("header, nav, main, aside, footer, section, article, form, [role=main], [role=navigation], [role=list], [data-testid], [class], [id]")];
    for (const element of nodes) {
      if (!(element instanceof HTMLElement) || element.closest("[data-redesigner-hud]")) continue;
      const rect = element.getBoundingClientRect(); if (rect.width < 80 || rect.height < 24) continue;
      const signature = `${element.tagName}:${element.id}:${String(element.className).slice(0,100)}`; if (seen.has(signature)) continue; seen.add(signature);
      const style = getComputedStyle(element);
      const links = [...element.querySelectorAll("a[href]")].slice(0,5).map(a=>({text:(a.innerText||a.getAttribute("aria-label")||"").trim().slice(0,60),href:a.href}));
      components.push({selector:selectorFor(element),tag:element.tagName.toLowerCase(),id:element.id||"",classes:typeof element.className==="string"?element.className.split(/\s+/).filter(Boolean).slice(0,8):[],role:element.getAttribute("role")||"",ariaLabel:element.getAttribute("aria-label")||"",textSample:textOf(element).slice(0,100),childCount:element.children.length,bounds:{x:Math.round(rect.x),y:Math.round(rect.y),width:Math.round(rect.width),height:Math.round(rect.height)},layout:{display:style.display,position:style.position,gridTemplateColumns:style.gridTemplateColumns,flexDirection:style.flexDirection,gap:style.gap},style:{fontFamily:style.fontFamily.slice(0,100),fontSize:style.fontSize,lineHeight:style.lineHeight,color:style.color,backgroundColor:style.backgroundColor,padding:style.padding,margin:style.margin,borderRadius:style.borderRadius},links});
      if(components.length>=70) break;
    }
    anatomy.components=components; anatomy.viewport={width:innerWidth,height:innerHeight,devicePixelRatio:devicePixelRatio||1};
    anatomy.resources={stylesheets:[...document.styleSheets].slice(0,40).map(sheet=>{try{return {href:sheet.href||"inline",accessibleRules:sheet.cssRules.length}}catch{return {href:sheet.href||"inline",accessibleRules:null,crossOrigin:true}}}),scripts:[...document.scripts].slice(0,40).map(script=>script.src||"inline"),images:document.images.length};
    anatomy.route=location.pathname+location.search; return anatomy;
  }

  // node_modules/idb/build/index.js
  var instanceOfAny = (object, constructors) => constructors.some((c) => object instanceof c);
  var idbProxyableTypes;
  var cursorAdvanceMethods;
  function getIdbProxyableTypes() {
    return idbProxyableTypes || (idbProxyableTypes = [
      IDBIndex,
      IDBObjectStore,
      IDBCursor,
      IDBDatabase,
      IDBTransaction
    ]);
  }
  function getCursorAdvanceMethods() {
    return cursorAdvanceMethods || (cursorAdvanceMethods = ["advance", "continue", "continuePrimaryKey"].map((method) => IDBCursor.prototype[method]));
  }
  var transactionDoneMap = /* @__PURE__ */ new WeakMap();
  var transformCache = /* @__PURE__ */ new WeakMap();
  var reverseTransformCache = /* @__PURE__ */ new WeakMap();
  function promisifyRequest(request) {
    const promise = new Promise((resolve, reject) => {
      const unlisten = () => {
        request.removeEventListener("success", success);
        request.removeEventListener("error", error);
      };
      const success = () => {
        resolve(wrap(request.result));
        unlisten();
      };
      const error = () => {
        reject(request.error);
        unlisten();
      };
      request.addEventListener("success", success);
      request.addEventListener("error", error);
    });
    reverseTransformCache.set(promise, request);
    return promise;
  }
  function cacheDonePromiseForTransaction(tx) {
    if (transactionDoneMap.has(tx))
      return;
    const done = new Promise((resolve, reject) => {
      const unlisten = () => {
        tx.removeEventListener("complete", complete);
        tx.removeEventListener("error", error);
        tx.removeEventListener("abort", error);
      };
      const complete = () => {
        resolve();
        unlisten();
      };
      const error = () => {
        reject(tx.error || new DOMException("AbortError", "AbortError"));
        unlisten();
      };
      tx.addEventListener("complete", complete);
      tx.addEventListener("error", error);
      tx.addEventListener("abort", error);
    });
    transactionDoneMap.set(tx, done);
  }
  var idbProxyTraps = {
    get(target, prop, receiver) {
      if (target instanceof IDBTransaction) {
        if (prop === "done")
          return transactionDoneMap.get(target);
        if (prop === "store") {
          return receiver.objectStoreNames[1] ? void 0 : receiver.objectStore(receiver.objectStoreNames[0]);
        }
      }
      return wrap(target[prop]);
    },
    set(target, prop, value) {
      target[prop] = value;
      return true;
    },
    has(target, prop) {
      if (target instanceof IDBTransaction && (prop === "done" || prop === "store")) {
        return true;
      }
      return prop in target;
    }
  };
  function replaceTraps(callback) {
    idbProxyTraps = callback(idbProxyTraps);
  }
  function wrapFunction(func) {
    if (getCursorAdvanceMethods().includes(func)) {
      return function(...args) {
        func.apply(unwrap(this), args);
        return wrap(this.request);
      };
    }
    return function(...args) {
      return wrap(func.apply(unwrap(this), args));
    };
  }
  function transformCachableValue(value) {
    if (typeof value === "function")
      return wrapFunction(value);
    if (value instanceof IDBTransaction)
      cacheDonePromiseForTransaction(value);
    if (instanceOfAny(value, getIdbProxyableTypes()))
      return new Proxy(value, idbProxyTraps);
    return value;
  }
  function wrap(value) {
    if (value instanceof IDBRequest)
      return promisifyRequest(value);
    if (transformCache.has(value))
      return transformCache.get(value);
    const newValue = transformCachableValue(value);
    if (!Object.is(newValue, value)) {
      transformCache.set(value, newValue);
      reverseTransformCache.set(newValue, value);
    }
    return newValue;
  }
  var unwrap = (value) => reverseTransformCache.get(value);
  function openDB(name, version, { blocked, upgrade, blocking, terminated } = {}) {
    const request = indexedDB.open(name, version);
    const openPromise = wrap(request);
    if (upgrade) {
      request.addEventListener("upgradeneeded", (event) => {
        upgrade(wrap(request.result), event.oldVersion, event.newVersion, wrap(request.transaction), event);
      });
    }
    if (blocked) {
      request.addEventListener("blocked", (event) => blocked(
        // Casting due to https://github.com/microsoft/TypeScript-DOM-lib-generator/pull/1405
        event.oldVersion,
        event.newVersion,
        event
      ));
    }
    openPromise.then((db) => {
      if (terminated)
        db.addEventListener("close", () => terminated());
      if (blocking) {
        db.addEventListener("versionchange", (event) => blocking(event.oldVersion, event.newVersion, event));
      }
    }).catch(() => {
    });
    return openPromise;
  }
  var readMethods = ["get", "getKey", "getAll", "getAllKeys", "count"];
  var writeMethods = ["put", "add", "delete", "clear"];
  var cachedMethods = {};
  function getMethod(target, prop) {
    if (!(target instanceof IDBDatabase && !(prop in target) && typeof prop === "string")) {
      return;
    }
    if (cachedMethods[prop])
      return cachedMethods[prop];
    const targetFuncName = prop.replace(/FromIndex$/, "");
    const useIndex = prop !== targetFuncName;
    const isWrite = writeMethods.includes(targetFuncName);
    if (
      // Bail if the target doesn't exist on the target. Eg, getAll isn't in Edge.
      !(targetFuncName in (useIndex ? IDBIndex : IDBObjectStore).prototype) || !(isWrite || readMethods.includes(targetFuncName))
    ) {
      return;
    }
    const method = async function(storeName, ...args) {
      const tx = this.transaction(storeName, isWrite ? "readwrite" : "readonly");
      let target2 = tx.store;
      if (useIndex)
        target2 = target2.index(args.shift());
      return (await Promise.all([
        target2[targetFuncName](...args),
        isWrite && tx.done
      ]))[0];
    };
    return cachedMethods[prop] = method;
  }
  replaceTraps((oldTraps) => ({
    ...oldTraps,
    get: (target, prop, receiver) => getMethod(target, prop) || oldTraps.get(target, prop, receiver),
    has: (target, prop) => !!getMethod(target, prop) || oldTraps.has(target, prop)
  }));
  var advanceMethodProps = ["advance", "continue", "continuePrimaryKey"];
  var methodMap = {};
  var advanceResults = /* @__PURE__ */ new WeakMap();
  var ittrProxiedCursorToOriginalProxy = /* @__PURE__ */ new WeakMap();
  var cursorIteratorTraps = {
    get(target, prop) {
      if (!advanceMethodProps.includes(prop))
        return target[prop];
      let cachedFunc = methodMap[prop];
      if (!cachedFunc) {
        cachedFunc = methodMap[prop] = function(...args) {
          advanceResults.set(this, ittrProxiedCursorToOriginalProxy.get(this)[prop](...args));
        };
      }
      return cachedFunc;
    }
  };
  async function* iterate(...args) {
    let cursor = this;
    if (!(cursor instanceof IDBCursor)) {
      cursor = await cursor.openCursor(...args);
    }
    if (!cursor)
      return;
    cursor = cursor;
    const proxiedCursor = new Proxy(cursor, cursorIteratorTraps);
    ittrProxiedCursorToOriginalProxy.set(proxiedCursor, cursor);
    reverseTransformCache.set(proxiedCursor, unwrap(cursor));
    while (cursor) {
      yield proxiedCursor;
      cursor = await (advanceResults.get(proxiedCursor) || cursor.continue());
      advanceResults.delete(proxiedCursor);
    }
  }
  function isIteratorProp(target, prop) {
    return prop === Symbol.asyncIterator && instanceOfAny(target, [IDBIndex, IDBObjectStore, IDBCursor]) || prop === "iterate" && instanceOfAny(target, [IDBIndex, IDBObjectStore]);
  }
  replaceTraps((oldTraps) => ({
    ...oldTraps,
    get(target, prop, receiver) {
      if (isIteratorProp(target, prop))
        return iterate;
      return oldTraps.get(target, prop, receiver);
    },
    has(target, prop) {
      return isIteratorProp(target, prop) || oldTraps.has(target, prop);
    }
  }));

  // src/content/blueprint-store.ts
  var dbPromise = openDB("redesigner-memory", 1, { upgrade(db) {
    db.createObjectStore("blueprints");
  } });
  async function getBlueprint(origin) {
    return (await dbPromise).get("blueprints", origin);
  }
  async function saveBlueprint(origin, blueprint) {
    await (await dbPromise).put("blueprints", blueprint, origin);
  }

  // src/content/content-script.ts
  var styleId = "redesigner-universal-style";
  var activeBlueprint;
  var enabled = true;
  var hudStatus = null;
  var lastMetrics = { zones: 0, grids: 0, cards: 0, layouts: 0, operations: 0 };
  var ownedStyles = new Map();
  var ownedAttributes = new Map();
  function setOwnedStyle(element, property, value) {
    if (!ownedStyles.has(element)) ownedStyles.set(element, new Map());
    const saved = ownedStyles.get(element);
    if (!saved.has(property)) saved.set(property, {
      value: element.style.getPropertyValue(property),
      priority: element.style.getPropertyPriority(property)
    });
    element.style.setProperty(property, String(value));
  }
  function setOwnedAttribute(element, name, value) {
    if (!ownedAttributes.has(element)) ownedAttributes.set(element, new Map());
    const saved = ownedAttributes.get(element);
    if (!saved.has(name)) saved.set(name, element.hasAttribute(name) ? element.getAttribute(name) : null);
    element.setAttribute(name, value);
  }
  function restorePageChanges() {
    for (const [element, properties] of ownedStyles) {
      for (const [property, previous] of properties) {
        if (previous.value) element.style.setProperty(property, previous.value, previous.priority);
        else element.style.removeProperty(property);
      }
    }
    for (const [element, attributes] of ownedAttributes) {
      for (const [name, previous] of attributes) {
        if (previous === null) element.removeAttribute(name);
        else element.setAttribute(name, previous);
      }
    }
    ownedStyles.clear();
    ownedAttributes.clear();
  }
  function setHudStatus(message, tone = "normal") {
    if (!hudStatus) return;
    hudStatus.textContent = message;
    hudStatus.dataset.tone = tone;
  }
  function markZones() {
    let zones = 0;
    for (const element of document.querySelectorAll("header, nav, main, aside, footer, form, section, [role]")) {
      if (element.closest("[data-redesigner-hud]")) continue;
      const signature = `${element.tagName} ${element.id} ${element.className} ${element.getAttribute("aria-label") || ""}`.toLowerCase();
      const role = element.tagName === "MAIN" ? "main" : /header|nav|masthead|topbar/.test(signature) ? "header" : /search|query|filter/.test(signature) ? "search" : /sidebar|aside|drawer|category|filter[-_ ]?panel/.test(signature) ? "secondary" : /footer|legal/.test(signature) ? "footer" : /action[-_ ]?bar|toolbar|account[-_ ]?menu|cart[-_ ]?summary|checkout[-_ ]?panel/.test(signature) ? "actions" : /advert|sponsor|cookie|consent|promo|newsletter/.test(signature) ? "clutter" : null;
      if (!role) continue;
      if (!element.hasAttribute("data-redesigner-role")) setOwnedAttribute(element, "data-redesigner-role", role);
      zones += 1;
    }
    if (!document.querySelector('[data-redesigner-role="main"]')) {
      const main = document.querySelector('article, [role="main"], body > div');
      if (main && !main.closest("[data-redesigner-hud]") && !main.hasAttribute("data-redesigner-role")) {
        setOwnedAttribute(main, "data-redesigner-role", "main");
        zones += 1;
      }
    }
    return zones;
  }
  function markContentGroups() {
    let grids = 0;
    let cards = 0;
    const mainRoots = [...document.querySelectorAll('[data-redesigner-role="main"]')].slice(0, 3);
    for (const root of mainRoots) {
      const parents = [root, ...root.querySelectorAll('section, ul, ol, [role="list"], div')];
      for (const parent of parents) {
        if (parent.closest('[data-redesigner-grid="true"]')) continue;
        const children = [...parent.children].filter((child) => {
          if (!(child instanceof HTMLElement) || child.dataset.redesignerHud !== void 0) return false;
          return Boolean(child.querySelector("img, video, picture, h1, h2, h3, h4, a, button")) && (child.textContent || "").trim().length > 20;
        });
        if (children.length < 3) continue;
        const signatures = /* @__PURE__ */ new Map();
        for (const child of children) {
          const signature = `${child.tagName}:${[...child.classList].slice(0, 2).join(".")}`;
          signatures.set(signature, [...signatures.get(signature) || [], child]);
        }
        const group = [...signatures.values()].sort((left, right) => right.length - left.length)[0];
        if (!group || group.length < 3) continue;
        if (!parent.hasAttribute("data-redesigner-grid")) setOwnedAttribute(parent, "data-redesigner-grid", "true");
        for (const card of group) {
          if (!card.hasAttribute("data-redesigner-card")) setOwnedAttribute(card, "data-redesigner-card", "true");
        }
        grids += 1;
        cards += group.length;
      }
    }
    return { grids, cards };
  }
  function arrangeSemanticZones(blueprint) {
    let layouts = 0;
    const byParent = /* @__PURE__ */ new Map();
    for (const role of blueprint.zoneOrder) {
      const element = document.querySelector(`[data-redesigner-role="${role}"]`);
      if (!element?.parentElement || element.parentElement.closest("[data-redesigner-role]")) continue;
      const siblings = byParent.get(element.parentElement) || [];
      if (!siblings.includes(element)) byParent.set(element.parentElement, [...siblings, element]);
    }
    for (const [parent, elements] of byParent) {
      if (elements.length < 2) continue;
      const ordered = blueprint.zoneOrder.map((role) => elements.find((element) => element.dataset.redesignerRole === role)).filter(Boolean);
      if (ordered.length < 2) continue;
      if (!parent.hasAttribute("data-redesigner-layout")) setOwnedAttribute(parent, "data-redesigner-layout", "true");
      setOwnedStyle(parent, "display", "grid");
      setOwnedStyle(parent, "grid-template-columns", "minmax(0, 1fr)");
      setOwnedStyle(parent, "grid-template-areas", ordered.map((element) => `"${element.dataset.redesignerRole}"`).join(" "));
      for (const element of ordered) {
        setOwnedStyle(element, "grid-area", element.dataset.redesignerRole || "main");
        setOwnedStyle(element, "min-width", "0");
      }
      layouts += 1;
    }
    return layouts;
  }
  function applyAiOperations(blueprint) {
    let applied = 0;
    for (const operation of blueprint.operations) {
      let target = null;
      try {
        target = document.querySelector(operation.selector);
      } catch {
        continue;
      }
      if (!target || target.closest("[data-redesigner-hud]")) continue;
      if (operation.kind === "grid") {
        setOwnedStyle(target, "display", "grid");
        setOwnedStyle(target, "grid-template-columns", `repeat(${Math.max(1, Math.min(operation.columns || 3, 5))}, minmax(0, 1fr))`);
        setOwnedStyle(target, "gap", `${Math.max(8, Math.min(operation.gap || 20, 48))}px`);
      } else if (operation.kind === "cards") {
        setOwnedStyle(target, "display", "grid");
        setOwnedStyle(target, "grid-template-columns", "repeat(auto-fit, minmax(min(240px, 100%), 1fr))");
        setOwnedStyle(target, "gap", `${Math.max(8, Math.min(operation.gap || 18, 40))}px`);
        for (const child of [...target.children]) {
          if (!(child instanceof HTMLElement)) continue;
          setOwnedStyle(child, "padding", "clamp(12px, 2vw, 22px)");
          setOwnedStyle(child, "border", "1px solid color-mix(in srgb, var(--rd-accent) 28%, transparent)");
          setOwnedStyle(child, "border-radius", `${Math.max(6, Math.min(operation.radius || 14, 24))}px`);
          setOwnedStyle(child, "background", "color-mix(in srgb, var(--rd-surface) 92%, transparent)");
          setOwnedStyle(child, "box-shadow", "0 12px 28px rgba(0,0,0,.12)");
        }
      } else if (operation.kind === "focus") {
        setOwnedStyle(target, "max-width", "900px");
        setOwnedStyle(target, "margin-inline", "auto");
        setOwnedStyle(target, "padding-inline", "clamp(16px, 4vw, 56px)");
      } else if (operation.kind === "rail") {
        setOwnedStyle(target, "max-width", "280px");
        setOwnedStyle(target, "position", "sticky");
        setOwnedStyle(target, "top", "16px");
        setOwnedStyle(target, "align-self", "start");
      } else if (operation.kind === "hide") {
        setOwnedStyle(target, "display", "none");
      }
      applied += 1;
    }
    return applied;
  }
  function applyBlueprint(blueprint) {
    restorePageChanges();
    if (!blueprint || !Array.isArray(blueprint.zoneOrder) || !Array.isArray(blueprint.hiddenRoles) || !Array.isArray(blueprint.operations)) {
      throw new Error("The redesign blueprint is incomplete.");
    }
    const zones = markZones();
    const groups = markContentGroups();
    const layouts = 0; // Preserve original structure unless a validated AI operation targets it.
    const operations = applyAiOperations(blueprint);
    lastMetrics = { zones, grids: groups.grids, cards: groups.cards, layouts, operations };
    console.groupCollapsed("[ReDesigner] Blueprint applied");
    console.log("Blueprint:", blueprint);
    console.log("Transformation metrics:", lastMetrics);
    console.groupEnd();
    activeBlueprint = blueprint;
    document.getElementById(styleId)?.remove();
    const hidden = blueprint.hiddenRoles.map((role) => `[data-redesigner-role="${role}"]`).join(",");
    const style = document.createElement("style");
    style.id = styleId;
    style.textContent = `:root{--rd-accent:${blueprint.accent};--rd-bg:${blueprint.background};--rd-surface:${blueprint.surface}}html.rd-active body{background:var(--rd-bg)!important;color-scheme:${blueprint.background.startsWith("#f") ? "light" : "dark"};font-family:ui-sans-serif,system-ui,sans-serif}html.rd-active [data-redesigner-role],html.rd-active [data-redesigner-grid]{transition:background .25s ease,box-shadow .25s ease}html.rd-active [data-redesigner-role="header"]{border-bottom:1px solid color-mix(in srgb,var(--rd-accent) 22%,transparent);backdrop-filter:blur(14px)}html.rd-active [data-redesigner-role="main"]{min-width:0}html.rd-active [data-redesigner-role="search"]{outline:1px solid color-mix(in srgb,var(--rd-accent) 55%,transparent);outline-offset:5px;border-radius:10px}html.rd-active [data-redesigner-role="secondary"]{background:color-mix(in srgb,var(--rd-surface) 72%,transparent);border-radius:12px}html.rd-active [data-redesigner-role="actions"] button,html.rd-active [data-redesigner-role="actions"] [role="button"]{accent-color:var(--rd-accent)}${hidden ? `html.rd-active ${hidden}{display:none!important}` : ""}html.rd-focus [data-redesigner-role="clutter"],html.rd-focus [data-redesigner-role="secondary"]{display:none!important}html.rd-focus [data-redesigner-role="main"]{max-width:900px;margin-inline:auto}`;
    document.documentElement.append(style);
    document.documentElement.classList.toggle("rd-active", enabled);
  }
  function createHud() {
    if (document.querySelector("[data-redesigner-hud]")) return;
    const host=document.createElement("div"); host.dataset.redesignerHud="true"; const shadow=host.attachShadow({mode:"open"});
    shadow.innerHTML=`<style>
      :host{all:initial;position:fixed;z-index:2147483647;right:18px;bottom:18px;font:13px/1.35 ui-sans-serif,system-ui;color:#eef6f5}*{box-sizing:border-box}
      .launcher{display:flex;align-items:center;gap:9px;border:1px solid #ffffff25;border-radius:999px;padding:9px 13px;background:#10181cf2;box-shadow:0 12px 40px #0008;backdrop-filter:blur(16px);cursor:pointer;font-weight:650}
      .mark{display:grid;place-items:center;width:26px;height:26px;border-radius:9px;background:#55d6be;color:#071411;font-size:11px;font-weight:900}.dot{width:7px;height:7px;border-radius:50%;background:#55d6be}
      .panel{width:min(680px,calc(100vw - 28px));border:1px solid #ffffff22;border-radius:18px;background:#10181cf5;box-shadow:0 16px 50px #000a;backdrop-filter:blur(18px);overflow:hidden}.panel[hidden],.launcher[hidden]{display:none}
      .top{display:flex;align-items:center;gap:8px;padding:12px 14px;border-bottom:1px solid #ffffff15}.top strong{font-size:13px}.top small{display:block;color:#9eb4b1;font-size:10px;margin-top:2px}.spacer{flex:1}.close{font-size:20px;line-height:1;padding:4px 8px!important;background:transparent!important}
      .status{padding:10px 14px 2px;color:#a8c1bb;font-size:11px}.status[data-tone=working]{color:#55d6be}.status[data-tone=error]{color:#ff9d8b}.status[data-tone=warning]{color:#e8b44c}.tools{display:flex;align-items:center;gap:6px;flex-wrap:wrap;padding:10px 12px 12px}
      button,input{border:0;border-radius:10px;padding:9px 10px;color:inherit;background:#ffffff12;font:inherit}button{cursor:pointer}button:hover{background:#ffffff25}input{min-width:150px;flex:1;outline:1px solid #ffffff12}.primary{background:#55d6be;color:#071411;font-weight:750}.foot{padding:0 14px 12px;color:#78908c;font-size:10px}
    </style><button class="launcher" data-open aria-label="Open ReDesigner"><span class="mark">RD</span><span>ReDesigner</span><span class="dot"></span></button><section class="panel" data-panel hidden><div class="top"><span class="mark">RD</span><div><strong>ReDesigner</strong><small>Website environment · experimental</small></div><span class="spacer"></span><button class="close" data-close aria-label="Close ReDesigner">×</button></div><div class="status" data-status>Inspecting page…</div><div class="tools"><button data-nav="header">Top</button><button data-nav="main">Main</button><button data-nav="actions">Actions</button><button data-nav="footer">End</button><button data-focus>Focus</button><button data-variation>Style</button><input data-prompt placeholder="Describe the redesign…" aria-label="Custom redesign instruction"/><button class="primary" data-send>Apply</button></div><div class="foot">Changes are experimental. Original page structure is preserved by default.</div></section>`;
    document.documentElement.append(host); hudStatus=shadow.querySelector("[data-status]"); const panel=shadow.querySelector("[data-panel]"); const launcher=shadow.querySelector("[data-open]");
    launcher.addEventListener("click",()=>{panel.hidden=false;launcher.hidden=true}); shadow.querySelector("[data-close]")?.addEventListener("click",()=>{panel.hidden=true;launcher.hidden=false});
    shadow.querySelectorAll("[data-nav]").forEach(button=>button.addEventListener("click",()=>document.querySelector(`[data-redesigner-role="${button.dataset.nav}"]`)?.scrollIntoView({behavior:"smooth",block:"start"})));
    shadow.querySelector("[data-focus]")?.addEventListener("click",()=>document.documentElement.classList.toggle("rd-focus"));
    shadow.querySelector("[data-variation]")?.addEventListener("click",()=>{const next=activeBlueprint?.variation==="vision"?"editorial":activeBlueprint?.variation==="editorial"?"executive":"vision";applyBlueprint(fallbackBlueprint(activeBlueprint?.archetype||"general",next));setHudStatus(`${next[0].toUpperCase()}${next.slice(1)} visual variation applied.`)});
    shadow.querySelector("[data-send]")?.addEventListener("click",()=>requestRedesign(shadow.querySelector("[data-prompt]").value)); shadow.querySelector("[data-prompt]")?.addEventListener("keydown",event=>{if(event.key==="Enter")requestRedesign(shadow.querySelector("[data-prompt]").value)});
  }
  async function requestRedesign(instruction) {
    setHudStatus("Mapping page and asking Groq...", "working");
    try {
      const anatomy = scanEnvironment();
      const response = await chrome.runtime.sendMessage({ type: "REDESIGN", anatomy, instruction });
      if (!response?.blueprint) throw new Error(response?.error || "No redesign blueprint returned by the extension service worker.");
      await saveBlueprint(location.origin + location.pathname, response.blueprint);
      applyBlueprint(response.blueprint);
      if (response.error) {
        setHudStatus(`AI unavailable · local fallback only · no AI design applied. ${response.error}`.slice(0, 260), "error");
      } else {
        const source = response.source === "groq" ? "Groq AI" : "Local theme";
        const detail = lastMetrics.operations ? `${lastMetrics.operations} targeted operations` : "style proposal only; no structural operations";
        setHudStatus(`${source} completed · ${detail} · ${lastMetrics.cards} cards detected.`, "normal");
      }
      const result = { ok: true, source: response.source || "offline", error: response.error || null, metrics: lastMetrics };
      console.info("[ReDesigner] Redesign response:", { ...result, blueprint: response.blueprint });
      return result;
    } catch (error) {
      const message = error?.message || "Unknown redesign error.";
      setHudStatus(`Redesign failed: ${message}`, "error");
      return { ok: false, error: message };
    }
  }
  async function init() {
    createHud();
    try {
      const settings = await chrome.storage.local.get(["enabled"]);
      enabled = settings.enabled !== false;
      if (!enabled) {
        setHudStatus("ReDesigner is paused for this page.");
        return;
      }
      const anatomy = scanEnvironment();
      const cached = await getBlueprint(location.origin + location.pathname);
      if (cached) setHudStatus(`Environment ready · ${anatomy.components.length} components mapped. Previous design available when requested.`);
      else setHudStatus(`Environment ready · ${anatomy.components.length} components mapped. Describe a goal to begin.`);
      const observer = new MutationObserver(() => markZones());
      observer.observe(document.documentElement, { childList: true, subtree: true });
    } catch (error) {
      const message = error?.message || "Unknown initialization error.";
      setHudStatus(`ReDesigner could not start: ${message}`, "error");
      console.error("[ReDesigner] Initialization failed:", error);
    }
  }
  void init();
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message?.type !== "REDESIGN_PAGE") return false;
    void requestRedesign(message.instruction).then(sendResponse).catch(error => {
      sendResponse({ ok: false, error: error?.message || "Page redesign failed." });
    });
    return true;
  });
})();
